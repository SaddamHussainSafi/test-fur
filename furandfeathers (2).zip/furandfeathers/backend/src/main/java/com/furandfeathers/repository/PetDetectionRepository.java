package com.furandfeathers.repository;

import com.furandfeathers.entity.PetDetection;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PetDetectionRepository extends JpaRepository<PetDetection, Long> {}