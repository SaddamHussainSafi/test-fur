package com.furandfeathers.dto;

public class CommentRequest {
    public String content;

    public CommentRequest() {}
}