package com.furandfeathers.controller;

import com.furandfeathers.entity.Pet;
import com.furandfeathers.model.ConversationState;
import com.furandfeathers.repository.PetRepository;
import com.furandfeathers.service.FurlyTrainingService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/furly")
public class FurlyController {

    private final FurlyTrainingService furlyService;
    private final ConversationState state = new ConversationState();

    private final PetRepository petRepository;

    public FurlyController(FurlyTrainingService furlyService, PetRepository petRepository) {
        this.furlyService = furlyService;
        this.petRepository = petRepository;
    }

    @PostMapping("/chat")
    public ResponseEntity<?> chat(@RequestBody Map<String, String> input) {
        String userMessage = input.get("message");
        if (userMessage == null || userMessage.trim().isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of("error", "Message is required"));
        }

        userMessage = userMessage.toLowerCase().trim();

        // Get current step
        String current = state.getStep();
        String next = furlyService.getNextContext(current);

        // Record answer for current step
        if (!"welcome".equals(current)) {
            state.updateState(userMessage, current);
        }

        // If we reached 5 questions, provide recommendations from DB
        if (state.isReadyForRecommendation()) {
            List<Map<String, Object>> recommendations = generateRecommendationFromDB(state.getAnswers());
            String response = "🎉 Perfect! Based on your answers, here are some pets you might consider:";
            return ResponseEntity.ok(Map.of("response", response, "recommendations", recommendations));
        }

        // Otherwise, find next question
        String question = furlyService.findResponseForContext(next);
        state.setStep(next);

        return ResponseEntity.ok(Map.of("response", question));
    }

    private List<Map<String, Object>> generateRecommendationFromDB(Map<String, String> answers) {
        String homeType = answers.getOrDefault("living_situation", "house").toLowerCase();
        // simple heuristic: prefer cats for apartments, dogs for houses
        String preferredSpecies = homeType.contains("apartment") || homeType.contains("flat") ? "Cat" : "Dog";

        List<Pet> pets = petRepository.findAllWithOwners();
        List<Pet> matches = new ArrayList<>();
        for (Pet p : pets) {
            if (p.getStatus() != null && p.getStatus().equalsIgnoreCase("Available")) {
                if (p.getSpecies() != null && p.getSpecies().equalsIgnoreCase(preferredSpecies)) {
                    matches.add(p);
                }
            }
        }

        // If no species matches, fall back to any available pets
        if (matches.isEmpty()) {
            for (Pet p : pets) {
                if (p.getStatus() != null && p.getStatus().equalsIgnoreCase("Available")) {
                    matches.add(p);
                }
            }
        }

        // Limit and build recommendation objects
        List<Map<String, Object>> recs = new ArrayList<>();
        int limit = Math.min(3, matches.size());
        for (int i = 0; i < limit; i++) {
            Pet p = matches.get(i);
            Map<String, Object> obj = new HashMap<>();
            obj.put("id", p.getId());
            obj.put("name", p.getName());
            obj.put("breed", p.getBreed());
            obj.put("age", p.getAge());
            obj.put("location", p.getLocation());
            obj.put("description", p.getDescription());
            obj.put("imageUrl", p.getImageUrl());
            String encoded = URLEncoder.encode(p.getName(), StandardCharsets.UTF_8).replace("+", "%20");
            obj.put("link", "http://localhost:3000/pet/" + encoded);
            recs.add(obj);
        }

        // Fallback if still empty
        if (recs.isEmpty()) {
            Map<String, Object> fallback = new HashMap<>();
            fallback.put("id", 0);
            fallback.put("name", "No pets available right now");
            fallback.put("description", "Please check back later or broaden your preferences.");
            fallback.put("link", "http://localhost:3000/pets");
            recs.add(fallback);
        }

        return recs;
    }

    @PostMapping("/reset")
    public ResponseEntity<?> reset() {
        state.reset();
        return ResponseEntity.ok(Map.of("response", "Conversation reset. Hi there! I'm Furly 🐾, your pet matching assistant! I'm so excited to help you find your new best friend! To get started, could you tell me a little bit about where you live? Do you have an apartment, a house with a yard, or something else?"));
    }
}