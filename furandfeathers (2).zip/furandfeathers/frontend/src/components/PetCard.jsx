import React from 'react';
import { Link } from 'react-router-dom';
import '../styles/pet-card.css';

const placeholderImage = 'https://place-puppy.com/400x400';

const truncateWords = (text, limit) => {
  if (!text) return '';
  const words = text.split(/\s+/).filter(Boolean);
  if (words.length <= limit) return words.join(' ');
  return `${words.slice(0, limit).join(' ')}...`;
};

const PetCard = ({ pet }) => {
  const imgSrc =
    pet.imageUrl ||
    (pet.imagePath ? `http://localhost:8080/${pet.imagePath}` : pet.image || pet.image_url || placeholderImage);

  const descriptionText = pet.description || `${pet.breed || pet.category || 'A companion'} looking for a home.`;
  const shortDesc = truncateWords(descriptionText, 5);
  const metaPrimary = pet.breed || pet.species || pet.category || 'Mixed companion';
  const metaSecondary = pet.age ? `${pet.age} yrs old` : null;
  const locationLabel = pet.location || pet.shelter || 'Location shared after match';

  return (
    <article className="pet-card">
      <div className="pet-card__media">
        <img src={imgSrc} alt={pet.name} loading="lazy" />
        {pet.status && (
          <span
            className={`pet-card__status-dot pet-card__status-dot--${pet.status.toLowerCase()}`}
            aria-label={pet.status}
            title={pet.status}
          >
            <span className="pet-card__status-label">{pet.status}</span>
          </span>
        )}
        {pet.gender && <span className="pet-card__gender-chip">{pet.gender}</span>}
      </div>

      <div className="pet-card__body">
        <div className="pet-card__meta">
          <span>{metaPrimary}</span>
          {metaSecondary && (
            <>
              <span className="pet-card__dot" aria-hidden="true" />
              <span>{metaSecondary}</span>
            </>
          )}
        </div>

        <h3 className="pet-card__name">{pet.name}</h3>
        <span className="pet-card__location pet-card__location--subtle">{locationLabel}</span>
        {shortDesc && <p className="pet-card__desc">{shortDesc}</p>}
      </div>

      <div className="pet-card__footer">
        <Link to={`/pet/${encodeURIComponent(pet.name)}`} className="pet-card__cta" aria-label={`View ${pet.name}`}>
          View profile
        </Link>
      </div>
    </article>
  );
};

export default PetCard;
