import React, { useState, useEffect } from "react";
import "../styles/hero-banner.css";

const HeroBanner = () => {
  const [timeOfDay, setTimeOfDay] = useState("morning");
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    const hour = new Date().getHours();
    if (hour >= 6 && hour < 12) setTimeOfDay("morning");
    else if (hour >= 12 && hour < 18) setTimeOfDay("evening");
    else setTimeOfDay("night");
  }, []);

  const getGradient = () => {
    switch (timeOfDay) {
      case "morning":
        return "linear-gradient(135deg, #FFE5B4 0%, #87CEEB 100%)";
      case "evening":
        return "linear-gradient(135deg, #FFD700 0%, #FFB6C1 100%)";
      case "night":
        return "linear-gradient(135deg, #191970 0%, #000080 100%)";
      default:
        return "linear-gradient(135deg, #FFE5B4 0%, #87CEEB 100%)";
    }
  };

  const handleSearchChange = (e) => {
    setSearchQuery(e.target.value);
  };

  return (
    <div
      className="hero-banner"
      style={{
        height: "600px",
        background: getGradient(),
        position: "relative",
        overflow: "hidden",
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
        alignItems: "center",
        color: "#fff",
        textAlign: "center",
        animation: "breathe 4s ease-in-out infinite",
      }}
    >
      {/* Animated particles */}
      <div className="particles">
        {[...Array(20)].map((_, i) => (
          <div
            key={i}
            className="particle"
            style={{
              left: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 3}s`,
              animationDuration: `${3 + Math.random() * 2}s`,
            }}
          />
        ))}
      </div>

      {/* Paw silhouettes */}
      <div className="paw-silhouettes">
        <div className="paw paw1">🐾</div>
        <div className="paw paw2">🐾</div>
        <div className="paw paw3">🐾</div>
      </div>

      <div className="hero-content" style={{ zIndex: 2, maxWidth: "800px", padding: "0 20px" }}>
        <h1
          style={{
            fontSize: "3.5rem",
            fontWeight: "300",
            marginBottom: "1rem",
            fontFamily: "Kanit, sans-serif",
            textShadow: "2px 2px 4px rgba(0,0,0,0.3)",
            animation: "fadeInUp 1s ease-out",
          }}
        >
          Find your forever friend.
          <br />
          <span style={{ fontSize: "2.5rem", fontWeight: "200" }}>
            Where love comes with fur, feathers, or fins.
          </span>
        </h1>

        <p
          style={{
            fontSize: "1.3rem",
            marginBottom: "2rem",
            opacity: 0.9,
            animation: "fadeInUp 1s ease-out 0.3s both",
          }}
        >
          Meet pets from local shelters — ready to bring warmth into your world.
        </p>

        <button
          className="hero-cta"
          style={{
            background: "rgba(255,255,255,0.2)",
            border: "2px solid rgba(255,255,255,0.5)",
            color: "#fff",
            padding: "15px 30px",
            fontSize: "1.2rem",
            borderRadius: "50px",
            cursor: "pointer",
            transition: "all 0.3s ease",
            marginBottom: "2rem",
            animation: "heartbeat 2s ease-in-out infinite",
            backdropFilter: "blur(10px)",
          }}
          onMouseEnter={(e) => {
            e.target.style.background = "rgba(255,255,255,0.3)";
            e.target.style.transform = "scale(1.05)";
          }}
          onMouseLeave={(e) => {
            e.target.style.background = "rgba(255,255,255,0.2)";
            e.target.style.transform = "scale(1)";
          }}
        >
          🐾 Discover Pets
        </button>

        {/* Micro search bar */}
        <div
          className="micro-search"
          style={{
            maxWidth: "400px",
            margin: "0 auto",
            position: "relative",
            animation: "fadeInUp 1s ease-out 0.6s both",
          }}
        >
          <input
            type="text"
            placeholder="Search by breed, color, or personality..."
            value={searchQuery}
            onChange={handleSearchChange}
            style={{
              width: "100%",
              padding: "12px 20px",
              borderRadius: "25px",
              border: "none",
              fontSize: "1rem",
              background: "rgba(255,255,255,0.9)",
              color: "#333",
              outline: "none",
              boxShadow: "0 4px 15px rgba(0,0,0,0.1)",
            }}
          />
          <div
            className="search-icon"
            style={{
              position: "absolute",
              right: "15px",
              top: "50%",
              transform: "translateY(-50%)",
              color: "#666",
            }}
          >
            🔍
          </div>
        </div>
      </div>
    </div>
  );
};

export default HeroBanner;