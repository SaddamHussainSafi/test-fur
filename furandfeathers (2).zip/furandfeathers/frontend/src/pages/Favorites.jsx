import React, { useContext } from 'react';
import { Link } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';
import SectionHero from '../components/SectionHero';

export default function Favorites() {
  const { user } = useContext(AuthContext);

  // Mock data - replace with actual API calls
  const favoritePets = [
    {
      id: 1,
      name: 'Bella',
      species: 'Dog',
      breed: 'Golden Retriever',
      age: '2 years',
      location: 'Happy Tails Shelter',
      image: 'https://via.placeholder.com/200x150?text=Bella',
      description: 'Friendly and energetic golden retriever looking for a loving home.'
    },
    {
      id: 2,
      name: 'Luna',
      species: 'Cat',
      breed: 'Siamese',
      age: '1 year',
      location: 'City Animal Shelter',
      image: 'https://via.placeholder.com/200x150?text=Luna',
      description: 'Playful Siamese cat with beautiful blue eyes.'
    },
  ];

  return (
    <div className="page">
      <SectionHero
        badge={<span>Saved</span>}
        title="My Favorite Pets"
        subtitle="Pets you've saved for later. Keep track of the ones you love!"
      />

      {favoritePets.length === 0 ? (
        <section className="page-section">
          <div className="surface-card" style={{ textAlign: 'center' }}>
            <h3>No favorite pets yet</h3>
            <p>Start browsing pets and add them to your favorites!</p>
            <Link to="/pets" className="site-button site-button--primary" style={{ marginTop: '10px' }}>
              Browse Pets
            </Link>
          </div>
        </section>
      ) : (
        <section className="page-section">
          <div className="section-grid section-grid--two">
            {favoritePets.map((pet) => (
              <div key={pet.id} className="surface-card">
                <img src={pet.imageUrl} alt={pet.name} style={{ width: '100%', height: 150, objectFit: 'cover', borderRadius: 12 }} />
                <h3 style={{ marginTop: '0.75rem' }}>{pet.name}</h3>
                <p><strong>Species:</strong> {pet.species}</p>
                <p><strong>Breed:</strong> {pet.breed}</p>
                <p><strong>Age:</strong> {pet.age}</p>
                <p><strong>Location:</strong> {pet.location}</p>
                <p>{pet.description}</p>
                <div className="form-actions" style={{ justifyContent: 'space-between' }}>
                  <Link to={`/pet/${encodeURIComponent(pet.name)}`} className="site-button site-button--ghost">View Details</Link>
                  <button className="site-button site-button--primary" onClick={() => console.log('Remove from favorites:', pet.id)}>Remove</button>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
