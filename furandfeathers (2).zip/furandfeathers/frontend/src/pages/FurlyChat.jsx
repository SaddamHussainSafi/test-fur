import React, {
  useState,
  useEffect,
  useContext,
  useRef,
  useCallback
} from 'react';
import { useNavigate } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';
import api from '../api';
import '../styles/furly-chat.css';

export default function FurlyChat() {
  const { user } = useContext(AuthContext);
  const navigate = useNavigate();
  const [message, setMessage] = useState('');
  const [furlyMessages, setFurlyMessages] = useState([]);
  const [isTyping, setIsTyping] = useState(false);
  const [initializing, setInitializing] = useState(true);
  const messagesRef = useRef(null);

  const buildMessage = useCallback((text, isUser, recommendations) => {
    return {
      id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
      text,
      isUser,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      recommendations
    };
  }, []);

  useEffect(() => {
    let isActive = true;

    const loadInitialMessage = async () => {
      try {
        const response = await api.post('/furly/reset');
        if (!isActive) return;
        const { response: text, recommendations } = response.data;
        setFurlyMessages([buildMessage(text, false, recommendations)]);
      } catch (error) {
        console.error('Error loading initial message:', error);
        if (!isActive) return;
        setFurlyMessages([
          buildMessage(
            "Hi there! I'm Furly, your pet-matching assistant. Tell me about your home, schedule, and dream pet so I can suggest the perfect match.",
            false
          )
        ]);
      } finally {
        if (isActive) {
          setInitializing(false);
        }
      }
    };

    loadInitialMessage();
    return () => {
      isActive = false;
    };
  }, [buildMessage]);

  useEffect(() => {
    if (messagesRef.current) {
      messagesRef.current.scrollTop = messagesRef.current.scrollHeight;
    }
  }, [furlyMessages, isTyping]);

  const handleViewPet = (pet) => {
    if (!pet) return;
    if (pet.link) {
      window.open(pet.link, '_blank', 'noopener');
      return;
    }
    if (pet.name) {
      navigate(`/pet/${encodeURIComponent(pet.name)}`);
    }
  };

  const handleSendMessage = async () => {
    const trimmed = message.trim();
    if (!trimmed || isTyping) {
      return;
    }

    const outgoing = buildMessage(trimmed, true);
    setFurlyMessages((prev) => [...prev, outgoing]);
    setMessage('');
    setIsTyping(true);

    try {
      const response = await api.post('/furly/chat', { message: trimmed });
      const { response: text, recommendations } = response.data;
      const incoming = buildMessage(text, false, recommendations);
      setFurlyMessages((prev) => [...prev, incoming]);
    } catch (error) {
      console.error('Error sending message to Furly:', error);
      setFurlyMessages((prev) => [
        ...prev,
        buildMessage('Oops, something went wrong. Please try again in a moment.', false)
      ]);
    } finally {
      setIsTyping(false);
    }
  };

  const handleComposerKeyDown = (event) => {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      handleSendMessage();
    }
  };

  const viewerLabel = user?.name || 'Guest visitor';

  return (
    <div className="furly-chat-page">
      <section className="surface-card furly-chat__hero">
        <div>
          <p className="furly-chat__eyebrow">AI companion assistant</p>
          <h1>Chat with Furly</h1>
          <p>
            Share your lifestyle, household, and the energy level you are hoping for. Furly will ask a
            few focused questions and recommend adoptable pets in real time.
          </p>
          <div className="furly-chat__meta">
            <span className="furly-chat__chip">You are chatting as {viewerLabel}</span>
            <span className="furly-chat__chip">Avg. reply under 2s</span>
            <span className="furly-chat__chip">Powered by shelter data</span>
          </div>
        </div>
        <div className="furly-chat__hero-panel">
          <div>
            <h3>How to get tailored matches</h3>
            <ul>
              <li>Mention your living space (apartment, house, yard, roommates).</li>
              <li>Share your daily routine or noise tolerance.</li>
              <li>Tell Furly about experience level or other pets at home.</li>
            </ul>
          </div>
          <div className="furly-chat__hero-card">
            <span className="furly-chat__status-dot" aria-hidden="true" />
            <div>
              <strong>Furly is online</strong>
              <p>We keep this chat secure and only use it to personalize pet matches.</p>
            </div>
          </div>
        </div>
      </section>

      <section className="surface-card furly-chat__panel">
        <header className="furly-chat__window-header">
          <div>
            <span className="furly-chat__status-badge">Live</span>
            <h3>Furly assistant</h3>
          </div>
          <p>Answer a few questions to unlock curated recommendations from nearby shelters.</p>
        </header>

        <div
          className="furly-chat__messages"
          ref={messagesRef}
          aria-live="polite"
          aria-busy={initializing}
        >
          {furlyMessages.length === 0 && !initializing && (
            <div className="furly-chat__empty-state">
              <p>Start by telling Furly about your home or ideal companion.</p>
            </div>
          )}

          {furlyMessages.map((msg) => (
            <article
              key={msg.id}
              className={`furly-chat__message ${msg.isUser ? 'is-user' : ''}`}
            >
              {!msg.isUser && (
                <div className="furly-chat__avatar" aria-hidden="true">
                  🐾
                </div>
              )}
              <div className="furly-chat__bubble">
                <p>{msg.text}</p>
                {Array.isArray(msg.recommendations) && msg.recommendations.length > 0 && (
                  <div className="furly-chat__recommendations">
                    <p className="furly-chat__recommendations-label">Matches to explore</p>
                    <div className="furly-chat__recommendation-grid">
                      {msg.recommendations.map((pet) => (
                        <article
                          key={pet.id || pet.name}
                          className="furly-chat__recommendation-card"
                        >
                          <div className="furly-chat__recommendation-media">
                            <img
                              src={pet.imageUrl || '/placeholder.jpg'}
                              alt={pet.name}
                              loading="lazy"
                            />
                          </div>
                          <div className="furly-chat__recommendation-body">
                            <strong>{pet.name}</strong>
                            <span>
                              {[pet.breed, pet.age && `${pet.age} yrs`, pet.location]
                                .filter(Boolean)
                                .join(' · ')}
                            </span>
                            {pet.description && <p>{pet.description}</p>}
                            <button
                              type="button"
                              className="site-button site-button--ghost furly-chat__recommendation-button"
                              onClick={() => handleViewPet(pet)}
                            >
                              View profile
                            </button>
                          </div>
                        </article>
                      ))}
                    </div>
                  </div>
                )}
                <span className="furly-chat__time">{msg.time}</span>
              </div>
            </article>
          ))}

          {isTyping && (
            <article className="furly-chat__message">
              <div className="furly-chat__avatar" aria-hidden="true">
                🐾
              </div>
              <div className="furly-chat__bubble">
                <div className="furly-chat__typing">
                  <span>Furly is typing</span>
                  <div className="furly-chat__typing-dots" aria-hidden="true">
                    <span />
                    <span />
                    <span />
                  </div>
                </div>
              </div>
            </article>
          )}
        </div>

        <div className="furly-chat__composer">
          <textarea
            rows={2}
            value={message}
            onChange={(event) => setMessage(event.target.value)}
            onKeyDown={handleComposerKeyDown}
            placeholder="Tell Furly about your living situation, routines, or dream pet..."
          />
          <button
            type="button"
            className="site-button site-button--primary"
            onClick={handleSendMessage}
            disabled={isTyping || !message.trim()}
          >
            {isTyping ? 'Matching...' : 'Send'}
          </button>
        </div>
      </section>
    </div>
  );
}
