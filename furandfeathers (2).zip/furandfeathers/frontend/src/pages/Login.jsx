import React, { useState, useContext, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";
import GoogleLoginButton from "../components/GoogleLoginButton";
import api from "../api";
import SectionHero from "../components/SectionHero";
import "../styles/forms.css";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const { login, user } = useContext(AuthContext);
  const navigate = useNavigate();

  useEffect(() => {
    if (user) {
      navigate("/dashboard");
    }
  }, [user, navigate]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    try {
      console.log("Attempting login with:", { email, password: "***" });
      const response = await api.post("/auth/login", { email, password });
      console.log("Login response:", response.data);
      if (response.data.status === "success") {
        login(response.data.user, response.data.token);
        navigate("/dashboard");
      } else {
        setError(response.data.message || "Login failed");
      }
    } catch (err) {
      console.error("Login error:", err);
      setError("Login failed. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = (user, token) => {
    login(user, token);
    navigate("/dashboard");
  };

  return (
    <div className="page">
      <SectionHero title="Welcome back" subtitle="Sign in to manage pets, messages, and your adoption journey." />
      <section className="page-section">
        {error && <div className="form-feedback form-feedback--error" style={{ marginBottom: '1rem' }}>{error}</div>}
        <form className="form-fields" onSubmit={handleSubmit}>
          <label className="form-group" htmlFor="email">
            <span>Email</span>
            <input type="email" id="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
          </label>
          <label className="form-group" htmlFor="password">
            <span>Password</span>
            <input type="password" id="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
          </label>
          <div className="form-actions">
            <button type="submit" disabled={loading} className="site-button site-button--primary">
              {loading ? "Logging in..." : "Login"}
            </button>
          </div>
        </form>
        <div className="form-helper" style={{ textAlign: 'center', margin: '1rem 0' }}>or</div>
        <GoogleLoginButton onLogin={handleGoogleLogin} />
        <div className="form-helper" style={{ textAlign: 'center', marginTop: '1rem' }}>
          Don't have an account? <Link to="/register" className="site-button site-button--ghost">Sign up</Link>
        </div>
      </section>
    </div>
  );
}

