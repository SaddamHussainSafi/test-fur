import React, { useState, useContext, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";
import GoogleLoginButton from "../components/GoogleLoginButton";
import api from "../api";
import SectionHero from "../components/SectionHero";
import "../styles/forms.css";

export default function Register() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [role, setRole] = useState("ADOPTER");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const { login, user } = useContext(AuthContext);
  const navigate = useNavigate();

  useEffect(() => {
    if (user) {
      navigate("/dashboard");
    }
  }, [user, navigate]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    if (password !== confirmPassword) {
      setError("Passwords do not match");
      return;
    }

    setLoading(true);

    try {
      console.log("Attempting registration with:", { name, email, password: "***", role });
      const response = await api.post("/auth/signup", { name, email, password, role });
      console.log("Registration response:", response.data);
      if (response.data.status === "success") {
        login(response.data.user, response.data.token);
        navigate("/redirect");
      } else {
        setError(response.data.message || "Registration failed");
      }
    } catch (err) {
      console.error("Registration error:", err);
      setError("Registration failed. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = (user, token) => {
    login(user, token);
    navigate("/dashboard");
  };

  return (
    <div className="page">
      <SectionHero title="Create your account" subtitle="Join the community and start your adoption journey." />
      <section className="page-section">
        {error && <div className="form-feedback form-feedback--error" style={{ marginBottom: '1rem' }}>{error}</div>}
        <form className="form-fields" onSubmit={handleSubmit}>
          <label className="form-group" htmlFor="name">
            <span>Name</span>
            <input type="text" id="name" value={name} onChange={(e) => setName(e.target.value)} required />
          </label>
          <label className="form-group" htmlFor="email">
            <span>Email</span>
            <input type="email" id="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
          </label>
          <label className="form-group" htmlFor="role">
            <span>Role</span>
            <select id="role" value={role} onChange={(e) => setRole(e.target.value)} required>
              <option value="">Select Role</option>
              <option value="ADOPTER">Adopter</option>
              <option value="SHELTER">Shelter</option>
            </select>
          </label>
          <label className="form-group" htmlFor="password">
            <span>Password</span>
            <input type="password" id="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
          </label>
          <label className="form-group" htmlFor="confirmPassword">
            <span>Confirm Password</span>
            <input type="password" id="confirmPassword" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} required />
          </label>
          <div className="form-actions">
            <button type="submit" disabled={loading} className="site-button site-button--primary">
              {loading ? "Signing up..." : "Sign Up"}
            </button>
          </div>
        </form>
        <div className="form-helper" style={{ textAlign: 'center', margin: '1rem 0' }}>or</div>
        <GoogleLoginButton onLogin={handleGoogleLogin} />
        <div className="form-helper" style={{ textAlign: 'center', marginTop: '1rem' }}>
          Already have an account? <Link to="/login" className="site-button site-button--ghost">Login</Link>
        </div>
      </section>
    </div>
  );
}
