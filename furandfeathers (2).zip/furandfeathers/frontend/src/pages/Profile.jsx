import React, { useContext, useState } from 'react';
import { AuthContext } from '../context/AuthContext';
import SectionHero from '../components/SectionHero';
import '../styles/forms.css';

export default function Profile() {
  const { user } = useContext(AuthContext);
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: user?.name || '',
    email: user?.email || '',
    phone: '',
    address: '',
    bio: '',
    // Shelter-specific fields
    shelterName: '',
    website: '',
    description: ''
  });

  const handleInputChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSave = () => {
    // Save profile data
    console.log('Saving profile:', formData);
    setIsEditing(false);
  };

  const isShelter = user?.role === 'shelter';

  return (
    <div className="page">
      <SectionHero
        title={isShelter ? 'Shelter Settings' : 'My Profile'}
        subtitle={isShelter ? 'Update your shelter details and preferences.' : 'Manage your personal information.'}
      />

      <section className="page-section">
        <div className="form-actions" style={{ justifyContent: 'space-between' }}>
          <h2 style={{ margin: 0 }}>Profile Information</h2>
          <button onClick={() => (isEditing ? handleSave() : setIsEditing(true))} className={`site-button ${isEditing ? 'site-button--primary' : 'site-button--ghost'}`}>
            {isEditing ? 'Save Changes' : 'Edit Profile'}
          </button>
        </div>

        <div className="form-fields">
          {/* Basic Info */}
          <label className="form-group">
            <span>Name</span>
            {isEditing ? (
              <input type="text" name="name" value={formData.name} onChange={handleInputChange} />
            ) : (
              <p className="form-helper" style={{ padding: '0.8rem', background: 'rgba(255,255,255,0.8)', borderRadius: 12 }}>{formData.name}</p>
            )}
          </label>

          <label className="form-group">
            <span>Email</span>
            {isEditing ? (
              <input type="email" name="email" value={formData.email} onChange={handleInputChange} />
            ) : (
              <p className="form-helper" style={{ padding: '0.8rem', background: 'rgba(255,255,255,0.8)', borderRadius: 12 }}>{formData.email}</p>
            )}
          </label>

          <label className="form-group">
            <span>Phone</span>
            {isEditing ? (
              <input type="tel" name="phone" value={formData.phone} onChange={handleInputChange} />
            ) : (
              <p className="form-helper" style={{ padding: '0.8rem', background: 'rgba(255,255,255,0.8)', borderRadius: 12 }}>{formData.phone || 'Not provided'}</p>
            )}
          </label>

          {/* Shelter-specific fields */}
          {isShelter && (
            <>
              <div>
                <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>Shelter Name:</label>
                {isEditing ? (
                  <input
                    type="text"
                    name="shelterName"
                    value={formData.shelterName}
                    onChange={handleInputChange}
                    style={{
                      width: '100%',
                      padding: '8px',
                      border: '1px solid #ddd',
                      borderRadius: '4px'
                    }}
                  />
                ) : (
                  <p style={{ margin: 0, padding: '8px', backgroundColor: '#f9f9f9', borderRadius: '4px' }}>
                    {formData.shelterName || 'Not set'}
                  </p>
                )}
              </div>

              <div>
                <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>Website:</label>
                {isEditing ? (
                  <input
                    type="url"
                    name="website"
                    value={formData.website}
                    onChange={handleInputChange}
                    style={{
                      width: '100%',
                      padding: '8px',
                      border: '1px solid #ddd',
                      borderRadius: '4px'
                    }}
                  />
                ) : (
                  <p style={{ margin: 0, padding: '8px', backgroundColor: '#f9f9f9', borderRadius: '4px' }}>
                    {formData.website || 'Not provided'}
                  </p>
                )}
              </div>

              <div>
                <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>Description:</label>
                {isEditing ? (
                  <textarea
                    name="description"
                    value={formData.description}
                    onChange={handleInputChange}
                    rows="4"
                    style={{
                      width: '100%',
                      padding: '8px',
                      border: '1px solid #ddd',
                      borderRadius: '4px',
                      resize: 'vertical'
                    }}
                  />
                ) : (
                  <p style={{ margin: 0, padding: '8px', backgroundColor: '#f9f9f9', borderRadius: '4px' }}>
                    {formData.description || 'No description provided'}
                  </p>
                )}
              </div>
            </>
          )}

          {/* Adopter-specific fields */}
          {!isShelter && (
            <>
              <div>
                <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>Address:</label>
                {isEditing ? (
                  <textarea
                    name="address"
                    value={formData.address}
                    onChange={handleInputChange}
                    rows="3"
                    style={{
                      width: '100%',
                      padding: '8px',
                      border: '1px solid #ddd',
                      borderRadius: '4px',
                      resize: 'vertical'
                    }}
                  />
                ) : (
                  <p style={{ margin: 0, padding: '8px', backgroundColor: '#f9f9f9', borderRadius: '4px' }}>
                    {formData.address || 'Not provided'}
                  </p>
                )}
              </div>

              <div>
                <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>Bio:</label>
                {isEditing ? (
                  <textarea
                    name="bio"
                    value={formData.bio}
                    onChange={handleInputChange}
                    rows="4"
                    placeholder="Tell us about yourself and what kind of pet you're looking for..."
                    style={{
                      width: '100%',
                      padding: '8px',
                      border: '1px solid #ddd',
                      borderRadius: '4px',
                      resize: 'vertical'
                    }}
                  />
                ) : (
                  <p style={{ margin: 0, padding: '8px', backgroundColor: '#f9f9f9', borderRadius: '4px' }}>
                    {formData.bio || 'No bio provided'}
                  </p>
                )}
              </div>
            </>
          )}
        </div>

        {isEditing && (
          <div className="form-actions">
            <button onClick={() => setIsEditing(false)} type="button" className="site-button site-button--ghost">Cancel</button>
          </div>
        )}
      </section>
    </div>
  );
}
