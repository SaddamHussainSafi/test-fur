import React, { useContext, useState, useEffect } from 'react';
import { AuthContext } from '../context/AuthContext';
import { useLocation } from 'react-router-dom';
import api from '../api';
import SectionHero from '../components/SectionHero';
import '../styles/messages.css';

export default function Messages() {
  const { user } = useContext(AuthContext);
  const location = useLocation();

  if (!user) {
    return (
      <div className="page">
        <SectionHero
          title="Please sign in to view messages"
          subtitle="You need to be logged in to access your conversations."
          badge={<span>Private area</span>}
        />
      </div>
    );
  }
  const [selectedChat, setSelectedChat] = useState(null);
  const [message, setMessage] = useState('');
  const [allUsers, setAllUsers] = useState([]);
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [loadingUsers, setLoadingUsers] = useState(false);

  // Check if we should start a conversation with someone
  useEffect(() => {
    if (location.state?.startConversationWith) {
      const targetUser = location.state.startConversationWith;
      startNewConversation(targetUser);
      // Clear the state to avoid re-triggering
      window.history.replaceState({}, document.title);
    }
  }, [location.state]);

  // Fetch all users on component mount or when user changes
  useEffect(() => {
    const loadUsers = async () => {
      try {
        await fetchAllUsers();
      } catch (error) {
        console.error('Failed to load users:', error);
      } finally {
        setLoading(false);
      }
    };
    loadUsers();
  }, [user]);

  // Fetch messages when a conversation is selected
  useEffect(() => {
    if (selectedChat) {
      fetchMessages(selectedChat.email);
    }
  }, [selectedChat]);

  const fetchConversations = async () => {
    try {
      const response = await api.get('/messages/conversations');
      setConversations(response.data);
    } catch (error) {
      console.error('Failed to fetch conversations:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchAllUsers = async () => {
    setLoadingUsers(true);
    try {
      // Fetch all users available for messaging
      const response = await api.get('/messages/users');
      // Filter out current user (should already be filtered by backend)
      const filteredUsers = response.data.filter(u => u.email !== user.email);
      setAllUsers(filteredUsers);
    } catch (error) {
      console.error('Failed to fetch users:', error);
      // Fallback: try a different endpoint or show an error
      alert('Unable to load users for new conversations. Please try again later.');
    } finally {
      setLoadingUsers(false);
    }
  };

  const startNewConversation = (selectedUser) => {
    setSelectedChat(selectedUser);
    setShowNewConversation(false);
    // Clear any existing messages since this is a new conversation
    setMessages([]);
  };

  const fetchMessages = async (email) => {
    try {
      const response = await api.get(`/messages/conversation/${email}`);
      setMessages(response.data);
      // Mark messages as read
      await api.post(`/messages/mark-read/${email}`);
    } catch (error) {
      console.error('Failed to fetch messages:', error);
    }
  };

  const handleSendMessage = async () => {
    if (message.trim() && selectedChat) {
      setSending(true);
      try {
        await api.post('/messages', {
          receiverEmail: selectedChat.email,
          content: message.trim()
        });
        setMessage('');
        // Refresh messages
        fetchMessages(selectedChat.email);
      } catch (error) {
        console.error('Failed to send message:', error);
        alert('Failed to send message. Please try again.');
      } finally {
        setSending(false);
      }
    }
  };

  const formatTime = (timestamp) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now - date;

    if (diff < 60000) return 'Just now';
    if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
    if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`;
    return `${Math.floor(diff / 86400000)}d ago`;
  };

  if (loading) {
    return (
      <div className="page">
        <SectionHero title="Messages" subtitle="Loading conversations..." />
      </div>
    );
  }

  return (
    <div className="chat-page">
      <SectionHero
        badge={<span>Private messages</span>}
        title="Messages"
        subtitle="Connect with adopters and shelters. Your conversations help move pets into loving homes."
      />
      <div className="chat-layout">
        {/* Contacts */}
        <div className="surface-card chat-sidebar">
          <div className="chat-sidebar__header">
            <h3 style={{ margin: 0 }}>Contacts</h3>
          </div>
          {loadingUsers ? (
            <div className="chat-empty" style={{ padding: '1rem' }}>Loading contacts...</div>
          ) : allUsers.length === 0 ? (
            <div className="chat-empty" style={{ padding: '1rem' }}>No contacts available.</div>
          ) : (
            <div className="chat-list">
              {allUsers.map((u) => (
                <div
                  key={u.id}
                  className={`chat-list__item ${selectedChat?.id === u.id ? 'is-active' : ''}`}
                  onClick={() => setSelectedChat(u)}
                >
                  <div className="chat-list__name">{u.name}</div>
                  <div className="chat-list__meta">{u.email}</div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Conversation */}
        <div className="surface-card chat-window">
          {selectedChat ? (
            <>
              <div className="chat-window__header">
                <h4 style={{ margin: 0 }}>{selectedChat.name}</h4>
              </div>
              <div className="chat-window__body">
                {messages.length === 0 ? (
                  <div className="chat-empty" style={{ minHeight: '220px' }}>
                    No messages yet. Start the conversation!
                  </div>
                ) : (
                  messages.map((msg) => {
                    const outgoing = msg.sender.email === user.email;
                    return (
                      <div key={msg.id} className="chat-message" style={{ textAlign: outgoing ? 'right' : 'left' }}>
                        <div className={`chat-bubble ${outgoing ? 'chat-bubble--outgoing' : ''}`}>
                          <div>{msg.content}</div>
                          <div className="chat-bubble__time">{formatTime(msg.timestamp)}</div>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
              <div className="chat-window__input">
                <input
                  type="text"
                  className="chat-input"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Type your message..."
                  onKeyDown={(e) => e.key === 'Enter' && !sending && handleSendMessage()}
                  disabled={sending}
                />
                <button
                  onClick={handleSendMessage}
                  disabled={sending || !message.trim()}
                  className="site-button site-button--primary"
                >
                  {sending ? 'Sending...' : 'Send'}
                </button>
              </div>
            </>
          ) : (
            <div className="chat-empty" style={{ minHeight: '320px' }}>
              Select a conversation to start messaging
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
