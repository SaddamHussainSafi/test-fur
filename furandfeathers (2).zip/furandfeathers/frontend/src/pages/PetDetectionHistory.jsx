import React, { useState, useEffect } from "react";
import axios from "axios";
import SectionHero from "../components/SectionHero";

const PetDetectionHistory = () => {
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchHistory = async () => {
      try {
        const res = await axios.get("http://localhost:8080/api/ai/history");
        setHistory(res.data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchHistory();
  }, []);

  if (loading) {
    return (
      <div className="page">
        <SectionHero title="Detection History" subtitle="Loading history..." />
      </div>
    );
  }

  return (
    <div className="page">
      <SectionHero
        badge={<span>AI powered</span>}
        title="Pet Detection History"
        subtitle="Review previous AI detections and insights."
      />
      <section className="page-section">
        {history.length === 0 ? (
          <div className="surface-card" style={{ textAlign: 'center' }}>
            <p>No detection history yet.</p>
          </div>
        ) : (
          <div className="section-grid section-grid--three">
            {history.map((item) => (
              <div key={item.id} className="surface-card">
                <small>ID: {item.id}</small>
                <small>Date: {new Date(item.createdAt || Date.now()).toLocaleDateString()}</small>
                <p style={{ whiteSpace: 'pre-line' }}><strong>Analysis:</strong> {item.analysis}</p>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
};

export default PetDetectionHistory;

