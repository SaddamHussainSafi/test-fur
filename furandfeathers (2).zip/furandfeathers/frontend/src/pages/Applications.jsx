import React, { useContext } from 'react';
import { AuthContext } from '../context/AuthContext';
import SectionHero from '../components/SectionHero';

export default function Applications() {
  const { user } = useContext(AuthContext);

  const applications = [
    { id: 1, petName: 'Bella', status: 'Pending', appliedDate: '2025-10-15' },
    { id: 2, petName: 'Max', status: 'Approved', appliedDate: '2025-10-10' },
    { id: 3, petName: 'Luna', status: 'Adopted', appliedDate: '2025-10-05' },
  ];

  const getStatusColor = (status) => {
    switch (status) {
      case 'Pending': return '#ffc107';
      case 'Approved': return '#28a745';
      case 'Adopted': return '#6c757d';
      default: return '#6c757d';
    }
  };

  if (user?.role === 'shelter') {
    return (
      <div className="page">
        <SectionHero badge={<span>Workflow</span>} title="Shelter Applications" subtitle="View and manage adoption applications for your pets." />
        <section className="page-section">
          <div className="section-grid">
            {applications.map((app) => (
              <div key={app.id} className="surface-card">
                <h3>Application for {app.petName}</h3>
                <p><strong>Applicant:</strong> John Doe</p>
                <p><strong>Status:</strong> <span style={{ color: getStatusColor(app.status), fontWeight: 'bold' }}>{app.status}</span></p>
                <p><strong>Applied:</strong> {app.appliedDate}</p>
                <div className="form-actions" style={{ justifyContent: 'flex-start' }}>
                  <button className="site-button site-button--primary">Approve</button>
                  <button className="site-button site-button--ghost">Reject</button>
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>
    );
  }

  return (
    <div className="page">
      <SectionHero badge={<span>My journey</span>} title="My Adoption Applications" subtitle="Track the status of your pet adoption applications." />
      <section className="page-section">
        <div className="section-grid">
          {applications.map((app) => (
            <div key={app.id} className="surface-card">
              <h3>Application for {app.petName}</h3>
              <p><strong>Status:</strong> <span style={{ color: getStatusColor(app.status), fontWeight: 'bold' }}>{app.status}</span></p>
              <p><strong>Applied:</strong> {app.appliedDate}</p>
              {app.status === 'Approved' && (
                <p style={{ color: '#28a745', fontWeight: 'bold' }}>Congratulations! Your application has been approved.</p>
              )}
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

