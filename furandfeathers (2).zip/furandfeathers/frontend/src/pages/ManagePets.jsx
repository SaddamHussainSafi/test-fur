import React, { useContext, useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';
import api from '../api';
import SectionHero from '../components/SectionHero';
import '../styles/table.css';
import '../styles/forms.css';
import '../styles/ui.css';

export default function ManagePets() {
  const { user } = useContext(AuthContext);
  const isAdmin = user?.role === 'admin' || user?.role === 'superadmin';
  const [filter, setFilter] = useState('all');
  const [pets, setPets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showEditModal, setShowEditModal] = useState(false);
  const [editingPet, setEditingPet] = useState(null);
  const [editForm, setEditForm] = useState({
    name: '',
    species: '',
    breed: '',
    age: '',
    gender: '',
    location: '',
    description: '',
    status: 'Available',
    image: null,
  });

  useEffect(() => {
    const fetchPets = async () => {
      try {
        // Check if user is admin or superadmin
        const isAdmin = user?.role === 'admin' || user?.role === 'superadmin';
        
        // Use different endpoint based on role
        const endpoint = isAdmin ? '/pets' : '/pets/my-pets';
        const response = await api.get(endpoint);
        console.log('API Response:', response.data); // Debug log
        
        let petsData;
        if (isAdmin) {
          // For admins, the response is already PetResponse objects
          petsData = response.data.map(pet => ({
            ...pet,
            status: pet.status || 'available',
            applications: pet.applications || 0,
            addedDate: pet.addedDate || new Date().toISOString().split('T')[0],
            listingStatus: pet.listingStatus || 'APPROVED'
          }));
        } else {
          // For regular users, transform as before
          petsData = response.data.map(pet => ({
            ...pet,
            status: pet.status || 'available',
            applications: pet.applications || 0,
            addedDate: pet.addedDate || new Date().toISOString().split('T')[0]
          }));
        }
        
        setPets(petsData);
      } catch (error) {
        console.error('Error fetching pets:', error);
        alert('Failed to load pets. Check console for details.');
      } finally {
        setLoading(false);
      }
    };
    if (user) {
      console.log('Current user:', user); // Debug log
      fetchPets();
    }
  }, [user]);

  const filteredPets = filter === 'all' ? pets : 
    filter === 'pending_review' ? pets.filter(pet => pet.listingStatus === 'PENDING_REVIEW') :
    pets.filter(pet => pet.status === filter);

  const relatedPets = pets
    .filter((pet) => pet.status === 'available')
    .slice(0, 4);

  if (loading) {
    return <div style={{ padding: '20px', textAlign: 'center' }}>Loading pets...</div>;
  }

  const getStatusColor = (status) => {
    switch (status) {
      case 'available': return '#28a745';
      case 'adopted': return '#6c757d';
      case 'pending': return '#ffc107';
      default: return '#6c757d';
    }
  };

  const formatDate = (value) => {
    if (!value) return '-';
    const parsed = new Date(value);
    if (Number.isNaN(parsed.getTime())) return value;
    return parsed.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });
  };

  const handleStatusChange = async (petId, newStatus) => {
    const formData = new FormData();
    formData.append('status', newStatus);
    // Add other required fields with current values
    const pet = pets.find(p => p.id === petId);
    if (pet) {
      formData.append('name', pet.name);
      formData.append('species', pet.species);
      formData.append('breed', pet.breed);
      formData.append('age', pet.age);
      formData.append('gender', pet.gender);
      formData.append('location', pet.location);
      formData.append('description', pet.description);
    }

    try {
      await api.put(`/pets/${petId}`, formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
      setPets(pets.map(p => p.id === petId ? { ...p, status: newStatus } : p));
    } catch (error) {
      console.error('Error updating status:', error);
      alert('Failed to update pet status');
    }
  };

  const handleEdit = (pet) => {
    setEditingPet(pet);
    setEditForm({
      name: pet.name,
      species: pet.species,
      breed: pet.breed,
      age: pet.age,
      gender: pet.gender,
      location: pet.location,
      description: pet.description,
      status: pet.status,
      image: null,
    });
    setShowEditModal(true);
  };

  const handleDelete = async (petId) => {
    if (window.confirm('Are you sure you want to delete this pet?')) {
      try {
        await api.delete(`/pets/${petId}`);
        setPets(pets.filter(pet => pet.id !== petId));
      } catch (error) {
        console.error('Error deleting pet:', error);
        alert('Failed to delete pet');
      }
    }
  };

  const handleDatabaseStatusChange = async (petId, newStatus) => {
    try {
      // Handle different status changes based on available endpoints
      if (newStatus === 'APPROVED') {
        await api.put(`/pets/${petId}/approve`);
      } else if (newStatus === 'REJECTED') {
        await api.put(`/pets/${petId}/reject`);
      } else if (newStatus === 'PENDING_REVIEW') {
        // For pending review, we need to set it back - this might require a backend change
        alert('Setting status to PENDING_REVIEW requires backend implementation');
        return;
      } else if (newStatus === 'DRAFT' || newStatus === 'ADOPTED') {
        // These statuses might need new backend endpoints
        alert(`Setting status to ${newStatus} requires backend implementation. Available: APPROVED, REJECTED`);
        return;
      }
      
      // Refresh pets
      const isAdmin = user?.role === 'ADMIN' || user?.role === 'SUPERADMIN';
      const endpoint = isAdmin ? '/pets' : '/pets/my-pets';
      const response = await api.get(endpoint);
      
      let petsData;
      if (isAdmin) {
        petsData = response.data.map(pet => ({
          ...pet,
          status: pet.status || 'available',
          applications: pet.applications || 0,
          addedDate: pet.addedDate || new Date().toISOString().split('T')[0],
          listingStatus: pet.listingStatus || 'APPROVED'
        }));
      } else {
        petsData = response.data.map(pet => ({
          ...pet,
          status: pet.status || 'available',
          applications: pet.applications || 0,
          addedDate: pet.addedDate || new Date().toISOString().split('T')[0]
        }));
      }
      
      setPets(petsData);
      alert(`Pet database status updated to ${newStatus} successfully!`);
    } catch (error) {
      console.error('Error updating database status:', error);
      alert('Failed to update pet database status');
    }
  };

  const handleEditChange = (e) => {
    const { name, value, files } = e.target;
    setEditForm({ ...editForm, [name]: files ? files[0] : value });
  };

  const handleUpdate = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    Object.entries(editForm).forEach(([key, value]) => {
      if (value !== null) formData.append(key, value);
    });

    try {
      await api.put(`/pets/${editingPet.id}`, formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
      // Refresh pets
      const isAdmin = user?.role === 'ADMIN' || user?.role === 'SUPERADMIN';
      const endpoint = isAdmin ? '/pets' : '/pets/my-pets';
      const response = await api.get(endpoint);
      
      let petsData;
      if (isAdmin) {
        petsData = response.data.map(pet => ({
          ...pet,
          status: pet.status || 'available',
          applications: pet.applications || 0,
          addedDate: pet.addedDate || new Date().toISOString().split('T')[0],
          listingStatus: pet.listingStatus || 'APPROVED'
        }));
      } else {
        petsData = response.data.map(pet => ({
          ...pet,
          status: pet.status || 'available',
          applications: pet.applications || 0,
          addedDate: pet.addedDate || new Date().toISOString().split('T')[0]
        }));
      }
      
      setPets(petsData);
      setShowEditModal(false);
      setEditingPet(null);
      alert('Pet updated successfully!');
    } catch (error) {
      console.error('Error updating pet:', error);
      alert('Failed to update pet');
    }
  };

  if (!user) {
    return (
      <div className="page">
        <SectionHero title="Please sign in" subtitle="You need to be logged in to manage your pets." />
      </div>
    );
  }

  return (
    <div className="page">
      <SectionHero
        badge={<span>Management</span>}
        title="Manage Pets"
        subtitle={`Logged in as: ${user?.name || 'Member'}${user?.role ? ` - ${user.role}` : ''}`}
        actions={(
          <div className="form-hero__actions">
            <Link to="/add-pet" className="site-button site-button--primary">Add New Pet</Link>
          </div>
        )}
      />

      <section className="page-section">
      {/* Filter Controls */}
      <div className="surface-card" style={{ marginBottom: '1rem' }}>
        <h3 className="section-heading">Filter Pets</h3>
        <div className="form-chip-group" role="radiogroup" aria-label="Filter">
          {[
            { value: 'all', label: `All Pets (${pets.length})` },
            { value: 'available', label: `Available (${pets.filter(p => p.status === 'available').length})` },
            { value: 'pending', label: `Pending Adoption (${pets.filter(p => p.status === 'pending').length})` },
            ...(isAdmin ? [{ value: 'pending_review', label: `Pending Review (${pets.filter(p => p.listingStatus === 'PENDING_REVIEW').length})` }] : []),
            { value: 'adopted', label: `Adopted (${pets.filter(p => p.status === 'adopted').length})` },
          ].map(opt => {
            const selected = filter === opt.value;
            const id = `filter-${opt.value}`;
            return (
              <label key={opt.value} htmlFor={id} className={`form-chip ${selected ? 'is-selected' : ''}`}>
                <input
                  id={id}
                  type="radio"
                  name="filter"
                  value={opt.value}
                  checked={selected}
                  onChange={(e) => setFilter(e.target.value)}
                />
                {opt.label}
              </label>
            );
          })}
        </div>
      </div>

      {/* Pets Grid */}
      <div className="pet-card-grid-wrapper">
        {filteredPets.length > 0 ? (
          <div className="pet-card-grid">
            {filteredPets.map((pet) => {
              const petImage = pet.imageUrl || pet.image || '/placeholder.jpg';
              const adoptionStatusClass = (pet.status || '').toLowerCase().replace(/\s+/g, '_');
              const listingStatusValue = pet.listingStatus || 'APPROVED';
              const listingStatusClass = listingStatusValue.toLowerCase().replace(/\s+/g, '_');
              const descriptionPreview = pet.description
                ? (pet.description.length > 110 ? `${pet.description.slice(0, 107)}...` : pet.description)
                : '';
              return (
                <article className="pet-profile-card" key={pet.id}>
                  <span className="pet-profile-card__glow" aria-hidden="true" />
                  <div className="pet-profile-card__image">
                    <img src={petImage} alt={pet.name} />
                    <span className="pet-profile-card__badge">{pet.species || '-'}</span>
                    <span className={`pet-profile-card__pill status-chip ${adoptionStatusClass ? `status-chip--${adoptionStatusClass}` : ''}`}>
                      {pet.status || '-'}
                    </span>
                  </div>
                  <div className="pet-profile-card__body">
                    <div className="pet-profile-card__top">
                      <div>
                        <h3>
                          {pet.name}
                          {pet.status === 'available' && (
                            <span className="pet-profile-card__verified" aria-label="Available and verified">
                              <svg viewBox="0 0 24 24" role="img" focusable="false">
                                <path d="M9.5 16.5l-3.5-3.5 1.41-1.41L9.5 13.67l7.09-7.09 1.41 1.41z" />
                              </svg>
                            </span>
                          )}
                        </h3>
                        <p>
                          {pet.breed || 'Mixed'} - {pet.age || 'Unknown age'}
                        </p>
                      </div>
                      <span className="pet-profile-card__location">{pet.location || 'Unknown location'}</span>
                    </div>

                    {descriptionPreview && (
                      <p className="pet-profile-card__description">{descriptionPreview}</p>
                    )}

                    <div className="pet-profile-card__stats">
                      <div className="pet-profile-card__stat">
                        <small>Applications</small>
                        <strong>{pet.applications || 0}</strong>
                      </div>
                      <div className="pet-profile-card__stat">
                        <small>Added</small>
                        <strong>{formatDate(pet.addedDate)}</strong>
                      </div>
                      {isAdmin && (
                        <div className="pet-profile-card__stat">
                          <small>Listing</small>
                          <span className={`status-chip ${listingStatusClass ? `status-chip--${listingStatusClass}` : ''}`}>
                            {listingStatusValue}
                          </span>
                        </div>
                      )}
                    </div>

                    <div className="pet-profile-card__control-row">
                      <div className="pet-profile-card__control">
                        <label htmlFor={`adoption-status-${pet.id}`}>Adoption status</label>
                        <select
                          id={`adoption-status-${pet.id}`}
                          className="pet-profile-card__select"
                          value={pet.status}
                          onChange={(e) => handleStatusChange(pet.id, e.target.value)}
                        >
                          <option value="available">Available</option>
                          <option value="pending">Pending</option>
                          <option value="adopted">Adopted</option>
                        </select>
                      </div>

                      {isAdmin && (
                        <div className="pet-profile-card__control">
                          <label htmlFor={`db-status-${pet.id}`}>Database status</label>
                          <select
                            id={`db-status-${pet.id}`}
                            className="pet-profile-card__select"
                            value={listingStatusValue}
                            onChange={(e) => handleDatabaseStatusChange(pet.id, e.target.value)}
                          >
                            <option value="APPROVED">Approved</option>
                            <option value="REJECTED">Rejected</option>
                          </select>
                        </div>
                      )}
                    </div>

                    <div className="pet-profile-card__actions">
                      <button type="button" className="pet-profile-card__button" onClick={() => handleEdit(pet)}>
                        Edit
                      </button>
                      <button
                        type="button"
                        className="pet-profile-card__button pet-profile-card__button--danger"
                        onClick={() => handleDelete(pet.id)}
                      >
                        Delete
                      </button>
                      <Link
                        to={`/pet/${encodeURIComponent(pet.name)}`}
                        className="pet-profile-card__button pet-profile-card__button--ghost"
                      >
                        View profile
                      </Link>
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        ) : (
          <div className="surface-card" style={{ textAlign: 'center' }}>
            <h3>No pets found</h3>
            <p>No pets match the selected filter.</p>
          </div>
        )}
      </div>

      {/* Summary Stats */}
      <div className="section-grid section-grid--four" style={{ marginTop: '1rem' }}>
        <div className="surface-card" style={{ textAlign: 'center' }}>
          <h3>{pets.filter(p => p.status === 'available').length}</h3>
          <small>Available Pets</small>
        </div>
        <div className="surface-card" style={{ textAlign: 'center' }}>
          <h3>{pets.filter(p => p.status === 'pending').length}</h3>
          <small>Pending Adoption</small>
        </div>
        {isAdmin && (
          <div className="surface-card" style={{ textAlign: 'center' }}>
            <h3>{pets.filter(p => p.listingStatus === 'PENDING_REVIEW').length}</h3>
            <small>Pending Review</small>
          </div>
        )}
        <div className="surface-card" style={{ textAlign: 'center' }}>
          <h3>{pets.filter(p => p.status === 'adopted').length}</h3>
          <small>Successfully Adopted</small>
        </div>
        <div className="surface-card" style={{ textAlign: 'center' }}>
          <h3>{pets.reduce((sum, pet) => sum + pet.applications, 0)}</h3>
          <small>Total Applications</small>
        </div>
      </div>

      {relatedPets.length > 0 && (
        <section className="related-pets-section">
          <div className="related-pets-section__header">
            <div>
              <h3>Related Pets</h3>
              <p>Available companions similar to your current listings.</p>
            </div>
            <Link to="/pets" className="related-pets-section__cta">Browse catalog</Link>
          </div>
          <div className="related-pets-grid">
            {relatedPets.map((pet) => {
              const petImage = pet.imageUrl || pet.image || '/placeholder.jpg';
              const statusClass = (pet.status || '').toLowerCase().replace(/\s+/g, '_');
              return (
                <article className="related-pet-card" key={`related-${pet.id}`}>
                  <img src={petImage} alt={pet.name} />
                  <div className="related-pet-card__body">
                    <strong>{pet.name}</strong>
                    <p>
                      {pet.breed || 'Mixed'} - {pet.location || 'Unknown location'}
                    </p>
                    <span className={`status-chip ${statusClass ? `status-chip--${statusClass}` : ''}`}>
                      {pet.status || '-'}
                    </span>
                  </div>
                  <Link to={`/pet/${encodeURIComponent(pet.name)}`} className="related-pet-card__button">
                    View
                  </Link>
                </article>
              );
            })}
          </div>
        </section>
      )}

      {/* Edit Modal */}
      {showEditModal && (
        <div className="modal-overlay" onClick={() => setShowEditModal(false)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <h2 style={{ marginTop: 0 }}>Edit Pet</h2>
            <form onSubmit={handleUpdate} encType="multipart/form-data">
              <div className="form-fields">
                <input
                  type="text"
                  name="name"
                  placeholder="Pet Name"
                  value={editForm.name}
                  onChange={handleEditChange}
                  required
                />
                <input
                  type="text"
                  name="species"
                  placeholder="Species"
                  value={editForm.species}
                  onChange={handleEditChange}
                  required
                />
                <input
                  type="text"
                  name="breed"
                  placeholder="Breed"
                  value={editForm.breed}
                  onChange={handleEditChange}
                  required
                />
                <input
                  type="text"
                  name="age"
                  placeholder="Age"
                  value={editForm.age}
                  onChange={handleEditChange}
                  required
                />
                <select
                  name="gender"
                  value={editForm.gender}
                  onChange={handleEditChange}
                  required
                >
                  <option value="">Select Gender</option>
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                </select>
                <input
                  type="text"
                  name="location"
                  placeholder="Location"
                  value={editForm.location}
                  onChange={handleEditChange}
                  required
                />
                <textarea
                  name="description"
                  placeholder="Description"
                  value={editForm.description}
                  onChange={handleEditChange}
                  rows="4"
                />
                <select
                  name="status"
                  value={editForm.status}
                  onChange={handleEditChange}
                >
                  <option value="Available">Available</option>
                  <option value="Pending">Pending</option>
                  <option value="Adopted">Adopted</option>
                </select>
                <input
                  type="file"
                  name="image"
                  accept="image/*"
                  onChange={handleEditChange}
                />
                <small>Leave empty to keep current image</small>
              </div>
              <div className="modal__footer">
                <button type="button" className="site-button site-button--ghost" onClick={() => setShowEditModal(false)}>Cancel</button>
                <button type="submit" className="site-button site-button--primary">Update Pet</button>
              </div>
            </form>
          </div>
        </div>
      )}

      </section>
    </div>
  );
}
