import React, { useState, useEffect } from "react";
import axios from "axios";

const PetDetectionHistory = () => {
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchHistory = async () => {
      try {
        const res = await axios.get("http://localhost:8080/api/ai/history");
        setHistory(res.data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchHistory();
  }, []);

  if (loading) return <div className="min-h-screen flex items-center justify-center">Loading history...</div>;

  return (
    <div className="min-h-screen bg-gradient-to-b from-orange-50 to-white py-10">
      <div className="container mx-auto px-4">
        <h1 className="text-3xl font-bold text-center mb-8">🐾 Pet Detection History</h1>
        {history.length === 0 ? (
          <p className="text-center text-gray-600">No detection history yet.</p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {history.map((item) => (
              <div key={item.id} className="bg-white shadow-lg p-6 rounded-xl">
                <p className="text-sm text-gray-500 mb-2">ID: {item.id}</p>
                <p className="text-sm text-gray-500 mb-4">Date: {new Date(item.createdAt || Date.now()).toLocaleDateString()}</p>
                <div className="text-gray-700 whitespace-pre-line">
                  <strong>Analysis:</strong> {item.analysis}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default PetDetectionHistory;