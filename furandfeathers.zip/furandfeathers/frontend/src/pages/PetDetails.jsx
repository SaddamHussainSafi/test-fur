import { useEffect, useState, useContext } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";
import api from "../utils/api";

export default function PetDetails() {
  const { name } = useParams();
  const { user } = useContext(AuthContext);
  const navigate = useNavigate();
  const [pet, setPet] = useState(null);
  const [relatedPets, setRelatedPets] = useState([]);
  const [storyMode, setStoryMode] = useState('human');
  const [likes, setLikes] = useState({ count: 0, liked: false });
  const [comments, setComments] = useState([]);
  const [newComment, setNewComment] = useState('');

  useEffect(() => {
    api.get(`/pets/name/${encodeURIComponent(name)}`)
      .then(res => {
        setPet(res.data);
        api.get(`/pets`)
          .then(relRes => setRelatedPets(relRes.data.filter(p => p.id !== res.data.id && p.breed === res.data.breed).slice(0, 5)))
          .catch(console.error);
      })
      .catch(console.error);

    api.get(`/pets/name/${encodeURIComponent(name)}`)
      .then(res => {
        const petId = res.data.id;
        api.get(`/pets/${petId}/likes`)
          .then(res => setLikes(res.data))
          .catch(console.error);
        api.get(`/pets/${petId}/comments`)
          .then(res => setComments(res.data))
          .catch(console.error);
      })
      .catch(console.error);
  }, [name]);

  const handleDelete = async () => {
    if (window.confirm("Are you sure you want to delete this pet?")) {
      try {
        await api.delete(`/pets/${pet?.id}`);
        navigate("/pets");
      } catch (err) {
        alert("Failed to delete pet");
      }
    }
  };

  const handleAdopt = () => {
    navigate(`/applications?petId=${pet?.id}`);
  };

  const handleLike = async () => {
    try {
      await api.post(`/pets/${pet?.id}/like`);
      const res = await api.get(`/pets/${pet?.id}/likes`);
      setLikes(res.data);
    } catch (err) {
      alert("Failed to toggle like");
    }
  };

  const handleAddComment = async () => {
    if (!newComment.trim()) return;
    try {
      await api.post(`/pets/${pet?.id}/comments`, { content: newComment });
      setNewComment('');
      const res = await api.get(`/pets/${pet?.id}/comments`);
      setComments(res.data);
    } catch (err) {
      alert("Failed to add comment");
    }
  };

  if (!pet) return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      fontFamily: "'Inter', 'Segoe UI', sans-serif"
    }}>
      <div className="glass-card" style={{
        padding: '40px',
        borderRadius: '24px',
        background: 'rgba(255, 255, 255, 0.1)',
        backdropFilter: 'blur(20px)',
        border: '1px solid rgba(255, 255, 255, 0.2)',
        boxShadow: '0 8px 32px rgba(0, 0, 0, 0.1)',
        color: 'white',
        fontSize: '18px'
      }}>
        Loading pet details...
      </div>
    </div>
  );

  const isOwner = user && pet.owner && user.id === pet.owner.id;
  const moodColor = pet.temperament === 'calm' ? '#667eea' : pet.temperament === 'energetic' ? '#f093fb' : '#4facfe';
  const petStory = `Woof! I'm ${pet.name}, a ${pet.age}-year-old ${pet.breed}. I love playing fetch and getting belly rubs. My human says I'm the best cuddler!`;

  return (
    <div style={{
      minHeight: '100vh',
      background: `linear-gradient(135deg, ${moodColor} 0%, #764ba2 50%, #f093fb 100%)`,
      fontFamily: "'Inter', 'Segoe UI', sans-serif",
      padding: '40px 20px',
      position: 'relative',
      overflow: 'hidden'
    }}>
      {/* Animated background elements */}
      <div style={{
        position: 'absolute',
        top: '10%',
        left: '5%',
        width: '300px',
        height: '300px',
        background: 'radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%)',
        borderRadius: '50%',
        animation: 'float 6s ease-in-out infinite',
        pointerEvents: 'none'
      }}></div>
      <div style={{
        position: 'absolute',
        bottom: '20%',
        right: '10%',
        width: '200px',
        height: '200px',
        background: 'radial-gradient(circle, rgba(255,255,255,0.08) 0%, transparent 70%)',
        borderRadius: '50%',
        animation: 'float 8s ease-in-out infinite 1s',
        pointerEvents: 'none'
      }}></div>

      <div style={{ maxWidth: '1400px', margin: '0 auto' }}>
        {/* Bento Grid Layout */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(12, 1fr)',
          gap: '20px',
          gridAutoRows: 'minmax(120px, auto)'
        }}>
          
          {/* Hero Card - Large */}
          <div className="glass-card" style={{
            gridColumn: 'span 12',
            gridRow: 'span 3',
            borderRadius: '32px',
            background: 'rgba(255, 255, 255, 0.15)',
            backdropFilter: 'blur(20px) saturate(180%)',
            border: '1px solid rgba(255, 255, 255, 0.3)',
            boxShadow: '0 8px 32px rgba(0, 0, 0, 0.1)',
            padding: '40px',
            display: 'flex',
            alignItems: 'center',
            gap: '40px',
            position: 'relative',
            overflow: 'hidden',
            transition: 'transform 0.3s ease, box-shadow 0.3s ease'
          }}>
            <div style={{
              position: 'relative',
              flexShrink: 0
            }}>
              <img
                src={pet.imageUrl}
                alt={pet.name}
                style={{
                  width: '280px',
                  height: '280px',
                  objectFit: 'cover',
                  borderRadius: '24px',
                  border: `4px solid rgba(255, 255, 255, 0.5)`,
                  boxShadow: '0 20px 60px rgba(0, 0, 0, 0.3)',
                  transition: 'transform 0.3s ease'
                }}
                onMouseEnter={(e) => e.target.style.transform = 'scale(1.05) rotate(2deg)'}
                onMouseLeave={(e) => e.target.style.transform = 'scale(1) rotate(0deg)'}
              />
              <div style={{
                position: 'absolute',
                top: '-10px',
                right: '-10px',
                background: 'rgba(255, 255, 255, 0.9)',
                borderRadius: '50%',
                width: '60px',
                height: '60px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '32px',
                boxShadow: '0 4px 15px rgba(0, 0, 0, 0.2)',
                animation: 'pulse 2s ease-in-out infinite'
              }}>
                💖
              </div>
            </div>
            
            <div style={{ flex: 1, color: 'white' }}>
              <h1 style={{
                fontSize: '56px',
                fontWeight: '800',
                margin: '0 0 20px 0',
                background: 'linear-gradient(135deg, #fff 0%, rgba(255,255,255,0.8) 100%)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                textShadow: '0 2px 10px rgba(0, 0, 0, 0.1)'
              }}>
                {pet.name}
              </h1>
              
              <div style={{
                display: 'flex',
                gap: '12px',
                flexWrap: 'wrap',
                marginBottom: '24px'
              }}>
                {[
                  { label: pet.breed, icon: '🐕' },
                  { label: `${pet.age} years`, icon: '🎂' },
                  { label: pet.gender, icon: pet.gender === 'Male' ? '♂️' : '♀️' },
                  { label: pet.location, icon: '📍' }
                ].map((tag, idx) => (
                  <span key={idx} style={{
                    background: 'rgba(255, 255, 255, 0.25)',
                    backdropFilter: 'blur(10px)',
                    padding: '10px 20px',
                    borderRadius: '16px',
                    fontSize: '16px',
                    fontWeight: '600',
                    border: '1px solid rgba(255, 255, 255, 0.3)',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px'
                  }}>
                    <span>{tag.icon}</span>
                    {tag.label}
                  </span>
                ))}
              </div>

              <div style={{
                display: 'flex',
                gap: '16px',
                alignItems: 'center',
                marginBottom: '20px'
              }}>
                {pet.vaccinated && (
                  <div style={{
                    background: 'rgba(255, 255, 255, 0.2)',
                    backdropFilter: 'blur(10px)',
                    padding: '12px 20px',
                    borderRadius: '12px',
                    fontSize: '14px',
                    fontWeight: '600',
                    border: '1px solid rgba(255, 255, 255, 0.3)'
                  }}>
                    🩺 Vaccinated
                  </div>
                )}
                {pet.trained && (
                  <div style={{
                    background: 'rgba(255, 255, 255, 0.2)',
                    backdropFilter: 'blur(10px)',
                    padding: '12px 20px',
                    borderRadius: '12px',
                    fontSize: '14px',
                    fontWeight: '600',
                    border: '1px solid rgba(255, 255, 255, 0.3)'
                  }}>
                    🐾 Trained
                  </div>
                )}
                {pet.goodWithKids && (
                  <div style={{
                    background: 'rgba(255, 255, 255, 0.2)',
                    backdropFilter: 'blur(10px)',
                    padding: '12px 20px',
                    borderRadius: '12px',
                    fontSize: '14px',
                    fontWeight: '600',
                    border: '1px solid rgba(255, 255, 255, 0.3)'
                  }}>
                    👨‍👩‍👧 Kid Friendly
                  </div>
                )}
              </div>

              {!isOwner ? (
                <button onClick={handleAdopt} style={{
                  padding: '18px 40px',
                  background: 'rgba(255, 255, 255, 0.95)',
                  color: moodColor,
                  border: 'none',
                  borderRadius: '16px',
                  fontSize: '18px',
                  fontWeight: '700',
                  cursor: 'pointer',
                  boxShadow: '0 8px 24px rgba(0, 0, 0, 0.15)',
                  transition: 'all 0.3s ease',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '10px'
                }}
                onMouseEnter={(e) => {
                  e.target.style.transform = 'translateY(-3px)';
                  e.target.style.boxShadow = '0 12px 32px rgba(0, 0, 0, 0.25)';
                }}
                onMouseLeave={(e) => {
                  e.target.style.transform = 'translateY(0)';
                  e.target.style.boxShadow = '0 8px 24px rgba(0, 0, 0, 0.15)';
                }}>
                  <span>Start Adoption Process</span>
                  <span style={{ fontSize: '24px' }}>💕</span>
                </button>
              ) : (
                <button onClick={() => navigate(`/manage-pets`)} style={{
                  padding: '18px 40px',
                  background: 'rgba(255, 255, 255, 0.2)',
                  color: 'white',
                  border: '2px solid rgba(255, 255, 255, 0.5)',
                  borderRadius: '16px',
                  fontSize: '18px',
                  fontWeight: '700',
                  cursor: 'pointer',
                  transition: 'all 0.3s ease'
                }}
                onMouseEnter={(e) => e.target.style.background = 'rgba(255, 255, 255, 0.3)'}
                onMouseLeave={(e) => e.target.style.background = 'rgba(255, 255, 255, 0.2)'}>
                  Manage Pets
                </button>
              )}
            </div>
          </div>

          {/* Play Level Card */}
          <div className="glass-card" style={{
            gridColumn: 'span 4',
            gridRow: 'span 1',
            borderRadius: '24px',
            background: 'rgba(255, 255, 255, 0.12)',
            backdropFilter: 'blur(20px) saturate(180%)',
            border: '1px solid rgba(255, 255, 255, 0.3)',
            boxShadow: '0 8px 32px rgba(0, 0, 0, 0.1)',
            padding: '28px',
            color: 'white',
            transition: 'transform 0.3s ease'
          }}
          onMouseEnter={(e) => e.target.style.transform = 'translateY(-5px)'}
          onMouseLeave={(e) => e.target.style.transform = 'translateY(0)'}>
            <div style={{ fontSize: '14px', fontWeight: '600', opacity: 0.9, marginBottom: '12px' }}>
              ENERGY LEVEL
            </div>
            <div style={{
              background: 'rgba(255, 255, 255, 0.2)',
              borderRadius: '12px',
              height: '16px',
              overflow: 'hidden',
              marginBottom: '8px'
            }}>
              <div style={{
                width: `${pet.playLevel || 50}%`,
                background: 'linear-gradient(90deg, rgba(255,255,255,0.9) 0%, rgba(255,255,255,0.6) 100%)',
                height: '100%',
                borderRadius: '12px',
                transition: 'width 1s ease'
              }}></div>
            </div>
            <div style={{ fontSize: '32px', fontWeight: '800' }}>
              {pet.playLevel || 50}%
            </div>
          </div>

          {/* Temperament Card */}
          <div className="glass-card" style={{
            gridColumn: 'span 4',
            gridRow: 'span 1',
            borderRadius: '24px',
            background: 'rgba(255, 255, 255, 0.12)',
            backdropFilter: 'blur(20px) saturate(180%)',
            border: '1px solid rgba(255, 255, 255, 0.3)',
            boxShadow: '0 8px 32px rgba(0, 0, 0, 0.1)',
            padding: '28px',
            color: 'white',
            transition: 'transform 0.3s ease'
          }}
          onMouseEnter={(e) => e.target.style.transform = 'translateY(-5px)'}
          onMouseLeave={(e) => e.target.style.transform = 'translateY(0)'}>
            <div style={{ fontSize: '14px', fontWeight: '600', opacity: 0.9, marginBottom: '12px' }}>
              TEMPERAMENT
            </div>
            <div style={{ fontSize: '32px', fontWeight: '800', textTransform: 'capitalize' }}>
              {pet.temperament}
            </div>
            <div style={{ fontSize: '40px', marginTop: '8px' }}>
              {pet.temperament === 'calm' ? '😌' : pet.temperament === 'energetic' ? '⚡' : '😊'}
            </div>
          </div>

          {/* Like Button Card */}
          {user && (
            <div className="glass-card" style={{
              gridColumn: 'span 4',
              gridRow: 'span 1',
              borderRadius: '24px',
              background: 'rgba(255, 255, 255, 0.12)',
              backdropFilter: 'blur(20px) saturate(180%)',
              border: '1px solid rgba(255, 255, 255, 0.3)',
              boxShadow: '0 8px 32px rgba(0, 0, 0, 0.1)',
              padding: '28px',
              color: 'white',
              cursor: 'pointer',
              transition: 'all 0.3s ease',
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'center',
              alignItems: 'center'
            }}
            onClick={handleLike}
            onMouseEnter={(e) => e.target.style.transform = 'translateY(-5px) scale(1.02)'}
            onMouseLeave={(e) => e.target.style.transform = 'translateY(0) scale(1)'}>
              <div style={{ fontSize: '48px', marginBottom: '12px' }}>
                {likes.liked ? '❤️' : '🤍'}
              </div>
              <div style={{ fontSize: '28px', fontWeight: '800' }}>
                {likes.count}
              </div>
              <div style={{ fontSize: '14px', opacity: 0.9, marginTop: '4px' }}>
                {likes.liked ? 'Liked' : 'Like'}
              </div>
            </div>
          )}

          {/* Story Section */}
          <div className="glass-card" style={{
            gridColumn: 'span 8',
            gridRow: 'span 2',
            borderRadius: '24px',
            background: 'rgba(255, 255, 255, 0.12)',
            backdropFilter: 'blur(20px) saturate(180%)',
            border: '1px solid rgba(255, 255, 255, 0.3)',
            boxShadow: '0 8px 32px rgba(0, 0, 0, 0.1)',
            padding: '32px',
            color: 'white',
            transition: 'transform 0.3s ease'
          }}
          onMouseEnter={(e) => e.target.style.transform = 'translateY(-5px)'}
          onMouseLeave={(e) => e.target.style.transform = 'translateY(0)'}>
            <div style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginBottom: '24px'
            }}>
              <h2 style={{
                fontSize: '28px',
                fontWeight: '700',
                margin: 0
              }}>
                Meet {pet.name}
              </h2>
              <button onClick={() => setStoryMode(storyMode === 'human' ? 'pet' : 'human')} style={{
                padding: '12px 24px',
                background: 'rgba(255, 255, 255, 0.25)',
                backdropFilter: 'blur(10px)',
                color: 'white',
                border: '1px solid rgba(255, 255, 255, 0.3)',
                borderRadius: '12px',
                cursor: 'pointer',
                fontSize: '14px',
                fontWeight: '600',
                transition: 'all 0.2s ease',
                display: 'flex',
                alignItems: 'center',
                gap: '8px'
              }}
              onMouseEnter={(e) => e.target.style.background = 'rgba(255, 255, 255, 0.35)'}
              onMouseLeave={(e) => e.target.style.background = 'rgba(255, 255, 255, 0.25)'}>
                <span>{storyMode === 'human' ? '🐶' : '👤'}</span>
                {storyMode === 'human' ? 'Pet Voice' : 'Human Voice'}
              </button>
            </div>
            <p style={{
              fontSize: '18px',
              lineHeight: '1.8',
              margin: 0,
              opacity: 0.95
            }}>
              {storyMode === 'human' ? pet.description : petStory}
            </p>
          </div>

          {/* Related Pets */}
          {relatedPets.length > 0 && (
            <div className="glass-card" style={{
              gridColumn: 'span 4',
              gridRow: 'span 2',
              borderRadius: '24px',
              background: 'rgba(255, 255, 255, 0.12)',
              backdropFilter: 'blur(20px) saturate(180%)',
              border: '1px solid rgba(255, 255, 255, 0.3)',
              boxShadow: '0 8px 32px rgba(0, 0, 0, 0.1)',
              padding: '32px',
              color: 'white',
              transition: 'transform 0.3s ease',
              overflow: 'hidden'
            }}
            onMouseEnter={(e) => e.target.style.transform = 'translateY(-5px)'}
            onMouseLeave={(e) => e.target.style.transform = 'translateY(0)'}>
              <h3 style={{
                fontSize: '22px',
                fontWeight: '700',
                marginBottom: '20px',
                margin: '0 0 20px 0'
              }}>
                Potential Playmates
              </h3>
              <div style={{
                display: 'flex',
                flexDirection: 'column',
                gap: '12px',
                maxHeight: '400px',
                overflowY: 'auto'
              }}>
                {relatedPets.map(relPet => (
                  <div key={relPet.id} onClick={() => navigate(`/pet/${encodeURIComponent(relPet.name)}`)} style={{
                    background: 'rgba(255, 255, 255, 0.15)',
                    backdropFilter: 'blur(10px)',
                    borderRadius: '16px',
                    padding: '12px',
                    cursor: 'pointer',
                    border: '1px solid rgba(255, 255, 255, 0.2)',
                    transition: 'all 0.2s ease',
                    display: 'flex',
                    gap: '12px',
                    alignItems: 'center'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.background = 'rgba(255, 255, 255, 0.25)';
                    e.currentTarget.style.transform = 'translateX(5px)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.background = 'rgba(255, 255, 255, 0.15)';
                    e.currentTarget.style.transform = 'translateX(0)';
                  }}>
                    <img src={relPet.imageUrl} alt={relPet.name} style={{
                      width: '60px',
                      height: '60px',
                      objectFit: 'cover',
                      borderRadius: '12px',
                      border: '2px solid rgba(255, 255, 255, 0.3)'
                    }} />
                    <div style={{ flex: 1 }}>
                      <div style={{ fontWeight: '700', fontSize: '16px' }}>
                        {relPet.name}
                      </div>
                      <div style={{ fontSize: '14px', opacity: 0.8 }}>
                        {relPet.breed}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Comments Section */}
          <div className="glass-card" style={{
            gridColumn: 'span 12',
            gridRow: 'span 3',
            borderRadius: '24px',
            background: 'rgba(255, 255, 255, 0.12)',
            backdropFilter: 'blur(20px) saturate(180%)',
            border: '1px solid rgba(255, 255, 255, 0.3)',
            boxShadow: '0 8px 32px rgba(0, 0, 0, 0.1)',
            padding: '32px',
            color: 'white'
          }}>
            <h2 style={{
              fontSize: '28px',
              fontWeight: '700',
              marginBottom: '28px',
              margin: '0 0 28px 0'
            }}>
              Comments ({comments.length})
            </h2>

            {user && (
              <div style={{
                marginBottom: '28px',
                background: 'rgba(255, 255, 255, 0.1)',
                backdropFilter: 'blur(10px)',
                borderRadius: '16px',
                padding: '20px',
                border: '1px solid rgba(255, 255, 255, 0.2)'
              }}>
                <div style={{ display: 'flex', gap: '16px' }}>
                  <img src={user.picture || '/default-avatar.png'} alt={user.name} style={{
                    width: '48px',
                    height: '48px',
                    borderRadius: '50%',
                    objectFit: 'cover',
                    border: '2px solid rgba(255, 255, 255, 0.5)',
                    flexShrink: 0
                  }} />
                  <div style={{ flex: 1 }}>
                    <textarea
                      value={newComment}
                      onChange={(e) => setNewComment(e.target.value)}
                      placeholder="Share your thoughts about this pet..."
                      style={{
                        width: '100%',
                        padding: '16px',
                        borderRadius: '12px',
                        border: '1px solid rgba(255, 255, 255, 0.3)',
                        minHeight: '100px',
                        fontFamily: "'Inter', 'Segoe UI', sans-serif",
                        fontSize: '16px',
                        resize: 'vertical',
                        background: 'rgba(255, 255, 255, 0.15)',
                        backdropFilter: 'blur(10px)',
                        color: 'white',
                        outline: 'none',
                        boxSizing: 'border-box'
                      }}
                      onFocus={(e) => e.target.style.borderColor = 'rgba(255, 255, 255, 0.6)'}
                      onBlur={(e) => e.target.style.borderColor = 'rgba(255, 255, 255, 0.3)'}
                    />
                    <div style={{
                      display: 'flex',
                      justifyContent: 'flex-end',
                      marginTop: '12px'
                    }}>
                      <button onClick={handleAddComment} style={{
                        padding: '12px 28px',
                        background: newComment.trim() ? 'rgba(255, 255, 255, 0.9)' : 'rgba(255, 255, 255, 0.2)',
                        color: newComment.trim() ? moodColor : 'white',
                        border: 'none',
                        borderRadius: '12px',
                        cursor: newComment.trim() ? 'pointer' : 'not-allowed',
                        fontSize: '16px',
                        fontWeight: '700',
                        transition: 'all 0.2s ease',
                        opacity: newComment.trim() ? 1 : 0.5
                      }}
                      onMouseEnter={(e) => {
                        if (newComment.trim()) {
                          e.target.style.transform = 'translateY(-2px)';
                        }
                      }}
                      onMouseLeave={(e) => {
                        e.target.style.transform = 'translateY(0)';
                      }}>
                        Comment
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}

            <div style={{
              maxHeight: '500px',
              overflowY: 'auto',
              paddingRight: '10px'
            }}>
              {comments.length === 0 ? (
                <div style={{
                  textAlign: 'center',
                  padding: '60px 20px',
                  opacity: 0.7
                }}>
                  <div style={{ fontSize: '48px', marginBottom: '16px' }}>💬</div>
                  <p style={{ fontSize: '18px', margin: 0 }}>
                    No comments yet. Be the first to share your thoughts!
                  </p>
                </div>
              ) : (
                comments.map(comment => (
                  <div key={comment.id} style={{
                    padding: '20px',
                    marginBottom: '16px',
                    background: 'rgba(255, 255, 255, 0.1)',
                    backdropFilter: 'blur(10px)',
                    borderRadius: '16px',
                    border: '1px solid rgba(255, 255, 255, 0.2)',
                    display: 'flex',
                    gap: '16px',
                    transition: 'all 0.2s ease'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.background = 'rgba(255, 255, 255, 0.15)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.background = 'rgba(255, 255, 255, 0.1)';
                  }}>
                    <img src={comment.user.picture || '/default-avatar.png'} alt={comment.user.name} style={{
                      width: '48px',
                      height: '48px',
                      borderRadius: '50%',
                      objectFit: 'cover',
                      border: '2px solid rgba(255, 255, 255, 0.4)',
                      flexShrink: 0
                    }} />
                    <div style={{ flex: 1 }}>
                      <div style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '12px',
                        marginBottom: '8px'
                      }}>
                        <strong style={{ fontSize: '16px' }}>
                          {comment.user.name}
                        </strong>
                        <span style={{
                          fontSize: '14px',
                          opacity: 0.7
                        }}>
                          {new Date(comment.createdAt).toLocaleDateString('en-US', {
                            year: 'numeric',
                            month: 'short',
                            day: 'numeric'
                          })}
                        </span>
                      </div>
                      <p style={{
                        margin: 0,
                        fontSize: '16px',
                        lineHeight: '1.6',
                        opacity: 0.95
                      }}>
                        {comment.content}
                      </p>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>

      <style jsx>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-20px); }
        }
        
        @keyframes pulse {
          0%, 100% { transform: scale(1); }
          50% { transform: scale(1.1); }
        }

        .glass-card:hover {
          box-shadow: 0 12px 48px rgba(0, 0, 0, 0.15);
        }

        /* Custom scrollbar for comments */
        div::-webkit-scrollbar {
          width: 8px;
        }

        div::-webkit-scrollbar-track {
          background: rgba(255, 255, 255, 0.1);
          border-radius: 10px;
        }

        div::-webkit-scrollbar-thumb {
          background: rgba(255, 255, 255, 0.3);
          border-radius: 10px;
        }

        div::-webkit-scrollbar-thumb:hover {
          background: rgba(255, 255, 255, 0.5);
        }

        @media (max-width: 1024px) {
          .glass-card[style*="span 12"] {
            flex-direction: column !important;
            text-align: center;
          }
          
          .glass-card[style*="span 4"],
          .glass-card[style*="span 8"] {
            grid-column: span 12 !important;
          }
        }

        @media (max-width: 768px) {
          .glass-card {
            grid-column: span 12 !important;
          }
        }
      `}</style>
    </div>
  );
}
