import React, { useState, useEffect } from "react";
import api from "../api";
import PetCard from "../components/PetCard";
import HeroBanner from "../components/HeroBanner";
import FilterSection from "../components/FilterSection";

const Pets = () => {
  const [pets, setPets] = useState([]);
  const [filteredPets, setFilteredPets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    species: [],
    moods: [],
    search: "",
    ageRange: [0, 20],
    location: "",
    gender: "",
    vaccinated: false,
    trained: false,
  });

  useEffect(() => {
    const fetchPets = async () => {
      try {
        const res = await api.get("/pets");
        setPets(res.data);
        setFilteredPets(res.data);
      } catch (err) {
        console.error("Error fetching pets:", err);
      } finally {
        setLoading(false);
      }
    };
    fetchPets();
  }, []);

  useEffect(() => {
    let filtered = [...pets];

    // Species filter
    if (filters.species.length > 0) {
      filtered = filtered.filter(pet =>
        filters.species.some(species =>
          pet.species?.toLowerCase().includes(species.toLowerCase()) ||
          (species === "dog" && pet.species?.toLowerCase().includes("dog")) ||
          (species === "cat" && pet.species?.toLowerCase().includes("cat")) ||
          (species === "bird" && pet.species?.toLowerCase().includes("bird")) ||
          (species === "rabbit" && pet.species?.toLowerCase().includes("rabbit")) ||
          (species === "other" && !["dog", "cat", "bird", "rabbit"].some(s =>
            pet.species?.toLowerCase().includes(s)
          ))
        )
      );
    }

    // Mood/Personality filter (this would need to be mapped from pet data)
    if (filters.moods.length > 0) {
      filtered = filtered.filter(pet => {
        // This is a simplified mapping - in real implementation, you'd have personality traits in pet data
        const petPersonality = pet.personality || pet.temperament || "";
        return filters.moods.some(mood => {
          switch (mood) {
            case "gentle":
              return petPersonality.toLowerCase().includes("gentle") || petPersonality.toLowerCase().includes("calm");
            case "energetic":
              return petPersonality.toLowerCase().includes("energetic") || petPersonality.toLowerCase().includes("active");
            case "calm":
              return petPersonality.toLowerCase().includes("calm") || petPersonality.toLowerCase().includes("quiet");
            case "playful":
              return petPersonality.toLowerCase().includes("playful") || petPersonality.toLowerCase().includes("fun");
            case "kidFriendly":
              return petPersonality.toLowerCase().includes("kid") || petPersonality.toLowerCase().includes("family");
            default:
              return false;
          }
        });
      });
    }

    // Search filter
    if (filters.search) {
      const searchLower = filters.search.toLowerCase();
      filtered = filtered.filter(pet =>
        pet.name?.toLowerCase().includes(searchLower) ||
        pet.breed?.toLowerCase().includes(searchLower) ||
        pet.species?.toLowerCase().includes(searchLower) ||
        pet.color?.toLowerCase().includes(searchLower) ||
        pet.personality?.toLowerCase().includes(searchLower)
      );
    }

    // Age range filter
    filtered = filtered.filter(pet => {
      const age = parseInt(pet.age) || 0;
      return age >= filters.ageRange[0] && age <= filters.ageRange[1];
    });

    // Location filter
    if (filters.location) {
      filtered = filtered.filter(pet =>
        pet.location?.toLowerCase().includes(filters.location.toLowerCase()) ||
        pet.shelter?.toLowerCase().includes(filters.location.toLowerCase())
      );
    }

    // Gender filter
    if (filters.gender) {
      filtered = filtered.filter(pet =>
        pet.gender?.toLowerCase() === filters.gender.toLowerCase()
      );
    }

    // Vaccination filter
    if (filters.vaccinated) {
      filtered = filtered.filter(pet => pet.vaccinated === true);
    }

    // Training filter
    if (filters.trained) {
      filtered = filtered.filter(pet => pet.trained === true);
    }

    setFilteredPets(filtered);
  }, [pets, filters]);

  const handleFiltersChange = (newFilters) => {
    setFilters(newFilters);
  };

  return (
    <section style={{ padding: '0', backgroundColor: '#f7f8fa' }}>
      <HeroBanner />
      <FilterSection onFiltersChange={handleFiltersChange} />

      <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '60px 20px' }}>
        <h2 style={{ textAlign: 'center', marginBottom: '40px', color: '#222', fontFamily: 'Kanit, sans-serif' }}>
          Available Pets {filteredPets.length !== pets.length && `(${filteredPets.length})`}
        </h2>

        {loading ? (
          <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap: '2rem' }}>
            {[...Array(8)].map((_, i) => (
              <div key={i} className="pet-card-clean" style={{ background: '#f9f9f9' }}>
                <div className="pet-img-box" style={{ background: '#e0e0e0' }}></div>
                <div className="pet-info" style={{ padding: '1.2rem 1.4rem' }}>
                  <div style={{ height: '20px', background: '#e0e0e0', marginBottom: '0.5rem' }}></div>
                  <div style={{ height: '24px', background: '#e0e0e0', marginBottom: '0.5rem' }}></div>
                  <div style={{ height: '40px', background: '#e0e0e0', marginBottom: '1rem' }}></div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <div style={{ height: '16px', width: '100px', background: '#e0e0e0' }}></div>
                    <div style={{ height: '32px', width: '80px', background: '#e0e0e0', borderRadius: '8px' }}></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : filteredPets.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '60px 20px' }}>
            <p style={{ fontSize: '1.2rem', color: '#666', marginBottom: '20px' }}>
              {pets.length === 0 ? "No pets available right now." : "No pets match your current filters."}
            </p>
            {pets.length > 0 && filteredPets.length === 0 && (
              <button
                onClick={() => setFilters({
                  species: [],
                  moods: [],
                  search: "",
                  ageRange: [0, 20],
                  location: "",
                  gender: "",
                  vaccinated: false,
                  trained: false,
                })}
                style={{
                  background: "#4ECDC4",
                  color: "#fff",
                  border: "none",
                  padding: "12px 24px",
                  borderRadius: "25px",
                  cursor: "pointer",
                  fontSize: "1rem",
                  fontWeight: "bold",
                }}
              >
                Clear Filters
              </button>
            )}
          </div>
        ) : (
          <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'center', alignItems: 'stretch', gap: '2rem', maxWidth: '1400px', margin: '0 auto' }}>
            {filteredPets.map((pet) => (
              <PetCard key={pet.id} pet={pet} />
            ))}
          </div>
        )}
      </div>
    </section>
  );
};

export default Pets;

