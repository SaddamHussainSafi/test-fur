import React, { useState, useEffect, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';
import api from '../api';

export default function FurlyChat() {
  const { user } = useContext(AuthContext);
  const navigate = useNavigate();
  const [message, setMessage] = useState('');
  const [furlyMessages, setFurlyMessages] = useState([]);
  const [isTyping, setIsTyping] = useState(false);

  useEffect(() => {
    // Load initial message
    const loadInitialMessage = async () => {
      try {
        const response = await api.post('/furly/reset');
        const data = response.data;
        setFurlyMessages([{ id: 1, text: data.response, isUser: false, time: new Date().toLocaleTimeString() }]);
      } catch (error) {
        console.error('Error loading initial message:', error);
        setFurlyMessages([{ id: 1, text: "Hi there! I'm Furly 🐾, your pet matching assistant!", isUser: false, time: new Date().toLocaleTimeString() }]);
      }
    };
    loadInitialMessage();

    // Add bounce animation CSS
    const style = document.createElement('style');
    style.textContent = `
      @keyframes bounce {
        0%, 80%, 100% { transform: scale(0); }
        40% { transform: scale(1); }
      }
      @keyframes fadeIn {
        from { opacity: 0; transform: translateY(20px); }
        to { opacity: 1; transform: translateY(0); }
      }
      .message-enter {
        animation: fadeIn 0.5s ease-out;
      }
    `;
    document.head.appendChild(style);
    return () => document.head.removeChild(style);
  }, []);

  const handleSendMessage = async () => {
    if (message.trim()) {
      const userMsg = { id: Date.now(), text: message, isUser: true, time: new Date().toLocaleTimeString() };
      setFurlyMessages(prev => [...prev, userMsg]);
      setMessage('');
      setIsTyping(true);

      try {
        const response = await api.post('/furly/chat', { message });
        const data = response.data;
        const furlyMsg = { id: Date.now() + 1, text: data.response, isUser: false, time: new Date().toLocaleTimeString() };
        if (data.recommendations) {
          furlyMsg.recommendations = data.recommendations;
        }
        setFurlyMessages(prev => [...prev, furlyMsg]);
      } catch (error) {
        console.error('Error sending message to Furly:', error);
        const errorMsg = { id: Date.now() + 1, text: 'Oops! Something went wrong. Please try again.', isUser: false, time: new Date().toLocaleTimeString() };
        setFurlyMessages(prev => [...prev, errorMsg]);
      } finally {
        setIsTyping(false);
      }
    }
  };

  return (
    <div style={{
      minHeight: '100vh',
      height: '100vh',
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'stretch',
      padding: '0',
    }}>
      <div style={{
        width: '100%',
        maxWidth: '1100px',
        background: 'rgba(255, 255, 255, 0.98)',
        borderRadius: '8px',
        boxShadow: '0 10px 30px rgba(0,0,0,0.25)',
        overflow: 'hidden',
        display: 'flex',
        flexDirection: 'column',
        height: '100vh',
        margin: '20px'
      }}>
        {/* Header */}
        <div style={{
          padding: '20px',
          background: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)',
          color: 'white',
          textAlign: 'center',
          position: 'relative'
        }}>
          <h2 style={{ margin: 0, fontFamily: "'Comic Sans MS', cursive, sans-serif" }}>Chat with Furly 🐾</h2>
          <p style={{ margin: '5px 0 0 0', opacity: 0.9 }}>Your AI Pet-Matching Assistant</p>
          <div style={{
            position: 'absolute',
            top: '10px',
            right: '20px',
            fontSize: '40px',
            opacity: 0.8
          }}>🐶</div>
        </div>

        {/* Messages */}
        <div style={{
          flex: 1,
          padding: '24px',
          overflowY: 'auto',
          background: 'url("data:image/svg+xml,%3Csvg width=\"60\" height=\"60\" viewBox=\"0 0 60 60\" xmlns=\"http://www.w3.org/2000/svg\"%3E%3Cg fill=\"none\" fill-rule=\"evenodd\"%3E%3Cg fill=\"%23f0f0f0\" fill-opacity=\"0.06\"%3E%3Ccircle cx=\"30\" cy=\"30\" r=\"4\"/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")',
          backgroundSize: '60px 60px',
          // reserve space for sticky input
          paddingBottom: '160px'
        }}>
          {furlyMessages.map(msg => (
            <div key={msg.id} className="message-enter" style={{
              marginBottom: '20px',
              textAlign: msg.isUser ? 'right' : 'left',
              display: 'flex',
              alignItems: 'flex-start',
              gap: '10px'
            }}>
              {!msg.isUser && <div style={{ fontSize: '30px', marginTop: '5px' }}>🐾</div>}
              {msg.recommendations ? (
                <div style={{
                  display: 'flex',
                  flexWrap: 'wrap',
                  gap: '15px',
                  maxWidth: '70%'
                }}>
                  {msg.recommendations.map(pet => (
                    <div key={pet.id} style={{
                      background: 'white',
                      borderRadius: '15px',
                      boxShadow: '0 4px 8px rgba(0,0,0,0.1)',
                      padding: '15px',
                      width: '250px',
                      border: '2px solid #f093fb'
                    }}>
                      <img src={pet.imageUrl} alt={pet.name} style={{
                        width: '100%',
                        height: '150px',
                        objectFit: 'cover',
                        borderRadius: '10px'
                      }} />
                      <h4 style={{ margin: '10px 0', color: '#333' }}>{pet.name}</h4>
                      <p style={{ margin: '5px 0', color: '#666' }}><strong>Breed:</strong> {pet.breed}</p>
                      <p style={{ margin: '5px 0', color: '#666' }}><strong>Age:</strong> {pet.age}</p>
                      <p style={{ margin: '5px 0', color: '#666' }}><strong>Location:</strong> {pet.location}</p>
                      <p style={{ margin: '5px 0', color: '#666', fontSize: '14px' }}>{pet.description}</p>
                      <button
                        onClick={() => {
                          if (pet.link) {
                            // open in new tab
                            window.open(pet.link, '_blank');
                          } else if (pet.id) {
                            navigate(`/pet/${encodeURIComponent(pet.name)}`);
                          }
                        }}
                        style={{
                        background: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)',
                        color: 'white',
                        border: 'none',
                        borderRadius: '20px',
                        padding: '8px 16px',
                        cursor: 'pointer',
                        fontWeight: 'bold',
                        marginTop: '10px'
                        }}>
                        View Details
                      </button>
                    </div>
                  ))}
                </div>
              ) : (
                <div style={{
                  display: 'inline-block',
                  maxWidth: '70%',
                  padding: '15px 20px',
                  borderRadius: '25px',
                  backgroundColor: msg.isUser ? '#4CAF50' : 'rgba(255,255,255,0.9)',
                  color: msg.isUser ? 'white' : '#333',
                  boxShadow: '0 4px 8px rgba(0,0,0,0.1)',
                  fontFamily: msg.isUser ? 'inherit' : "'Comic Sans MS', cursive, sans-serif",
                  border: msg.isUser ? 'none' : '2px solid #f093fb'
                }}>
                  <div style={{ fontSize: '16px', lineHeight: '1.4' }}>{msg.text}</div>
                  <div style={{ fontSize: '12px', opacity: 0.7, marginTop: '8px' }}>{msg.time}</div>
                </div>
              )}
              {msg.isUser && <div style={{ fontSize: '30px', marginTop: '5px' }}>👤</div>}
            </div>
          ))}
          {isTyping && (
            <div style={{ textAlign: 'left', marginBottom: '20px', display: 'flex', alignItems: 'flex-start', gap: '10px' }}>
              <div style={{ fontSize: '30px', marginTop: '5px' }}>🐾</div>
              <div style={{
                display: 'inline-block',
                padding: '15px 20px',
                borderRadius: '25px',
                backgroundColor: 'rgba(255,255,255,0.9)',
                boxShadow: '0 4px 8px rgba(0,0,0,0.1)',
                fontFamily: "'Comic Sans MS', cursive, sans-serif",
                border: '2px solid #f093fb'
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                  <span>Furly is typing...</span>
                  <div style={{ display: 'flex', gap: '3px' }}>
                    <div style={{ width: '6px', height: '6px', backgroundColor: '#f5576c', borderRadius: '50%', animation: 'bounce 1.4s infinite ease-in-out both' }}></div>
                    <div style={{ width: '6px', height: '6px', backgroundColor: '#f5576c', borderRadius: '50%', animation: 'bounce 1.4s infinite ease-in-out 0.16s both' }}></div>
                    <div style={{ width: '6px', height: '6px', backgroundColor: '#f5576c', borderRadius: '50%', animation: 'bounce 1.4s infinite ease-in-out 0.32s both' }}></div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Input */}
        <div style={{
          padding: '18px',
          background: 'white',
          borderTop: '1px solid #eee',
          display: 'flex',
          gap: '15px',
          alignItems: 'center',
          position: 'sticky',
          bottom: 0,
          zIndex: 20
        }}>
          <input
            type="text"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Tell Furly about your dream pet! 🐶🐱"
            style={{
              flex: 1,
              padding: '15px 20px',
              border: '2px solid #f093fb',
              borderRadius: '30px',
              fontSize: '16px',
              outline: 'none',
              transition: 'border-color 0.3s'
            }}
            onFocus={(e) => e.target.style.borderColor = '#f5576c'}
            onBlur={(e) => e.target.style.borderColor = '#f093fb'}
            onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
          />
          <button
            onClick={handleSendMessage}
            disabled={isTyping}
            style={{
              padding: '15px 30px',
              background: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)',
              color: 'white',
              border: 'none',
              borderRadius: '30px',
              cursor: isTyping ? 'not-allowed' : 'pointer',
              fontWeight: 'bold',
              fontSize: '16px',
              transition: 'transform 0.2s, box-shadow 0.2s',
              boxShadow: '0 4px 15px rgba(245, 87, 108, 0.3)'
            }}
            onMouseOver={(e) => {
              if (!isTyping) {
                e.target.style.transform = 'scale(1.05)';
                e.target.style.boxShadow = '0 6px 20px rgba(245, 87, 108, 0.4)';
              }
            }}
            onMouseOut={(e) => {
              e.target.style.transform = 'scale(1)';
              e.target.style.boxShadow = '0 4px 15px rgba(245, 87, 108, 0.3)';
            }}
          >
            {isTyping ? '...' : 'Send 🐾'}
          </button>
        </div>
      </div>
    </div>
  );
}