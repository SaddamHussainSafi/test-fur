import React, { useState } from "react";
import axios from "axios";

const PetDetection = () => {
  const [image, setImage] = useState(null);
  const [preview, setPreview] = useState("");
  const [result, setResult] = useState("");
  const [parsedResult, setParsedResult] = useState({});
  const [loading, setLoading] = useState(false);

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    setImage(file);
    setPreview(URL.createObjectURL(file));
  };

  const parseAnalysis = (text) => {
    const parsed = {};
    // Simple parsing based on keywords
    const lines = text.split('.').map(line => line.trim()).filter(line => line);
    lines.forEach(line => {
      if (line.toLowerCase().includes('species') || line.toLowerCase().includes('appears to be')) {
        parsed.species = line;
      } else if (line.toLowerCase().includes('breed')) {
        parsed.breed = line;
      } else if (line.toLowerCase().includes('age') || line.toLowerCase().includes('years old')) {
        parsed.age = line;
      } else if (line.toLowerCase().includes('color') || line.toLowerCase().includes('fur')) {
        parsed.color = line;
      } else if (line.toLowerCase().includes('emotion') || line.toLowerCase().includes('emotional state')) {
        parsed.emotion = line;
      } else if (line.toLowerCase().includes('size')) {
        parsed.size = line;
      } else if (line.toLowerCase().includes('gender')) {
        parsed.gender = line;
      } else if (line.toLowerCase().includes('distinctive') || line.toLowerCase().includes('features')) {
        parsed.features = line;
      }
    });
    return parsed;
  };

  const handleUpload = async () => {
    if (!image) return alert("Please select an image first");
    setLoading(true);
    const formData = new FormData();
    formData.append("image", image);
    try {
      const res = await axios.post("http://localhost:8080/api/ai/pet-detect", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      setResult(res.data.analysis);
      setParsedResult(parseAnalysis(res.data.analysis));
    } catch (err) {
      console.error(err);
      setResult("Error analyzing image.");
      setParsedResult({});
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-orange-50 to-white flex flex-col items-center py-10">
      <h1 className="text-3xl font-bold mb-6">🐾 AI Pet Detection</h1>
      <input type="file" accept="image/*" onChange={handleFileChange} className="mb-4" />
      {preview && <img src={preview} alt="preview" className="w-72 h-72 object-cover rounded-2xl mb-6 shadow-md" />}
      <button
        onClick={handleUpload}
        className="px-6 py-2 bg-orange-500 text-white rounded-full hover:bg-orange-600 transition-all"
        disabled={loading}
      >
        {loading ? "Analyzing..." : "Detect Pet Info"}
      </button>

      {Object.keys(parsedResult).length > 0 && (
        <div className="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 w-full max-w-4xl">
          {Object.entries(parsedResult).map(([key, value]) => (
            <div key={key} className="bg-white shadow-lg p-4 rounded-xl text-gray-700">
              <h3 className="font-semibold text-lg capitalize mb-2">{key}</h3>
              <p>{value}</p>
            </div>
          ))}
        </div>
      )}

      {result && !Object.keys(parsedResult).length && (
        <div className="mt-8 bg-white shadow-lg p-6 rounded-xl w-96 text-gray-700 whitespace-pre-line">
          <h2 className="font-semibold text-xl mb-2">Analysis Result:</h2>
          <p>{result}</p>
        </div>
      )}
    </div>
  );
};

export default PetDetection;