import React, { useContext, useState, useEffect } from 'react';
import { AuthContext } from '../context/AuthContext';
import api from '../api';

export default function Messages() {
  const { user } = useContext(AuthContext);
  const [selectedChat, setSelectedChat] = useState(null);
  const [message, setMessage] = useState('');
  const [conversations, setConversations] = useState([]);
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [showNewConversation, setShowNewConversation] = useState(false);
  const [allUsers, setAllUsers] = useState([]);
  const [loadingUsers, setLoadingUsers] = useState(false);

  // Fetch conversations on component mount
  useEffect(() => {
    fetchConversations();
  }, []);

  // Fetch messages when a conversation is selected
  useEffect(() => {
    if (selectedChat) {
      fetchMessages(selectedChat.email);
    }
  }, [selectedChat]);

  const fetchConversations = async () => {
    try {
      const response = await api.get('/messages/conversations');
      setConversations(response.data);
    } catch (error) {
      console.error('Failed to fetch conversations:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchAllUsers = async () => {
    setLoadingUsers(true);
    try {
      // Fetch all users available for messaging
      const response = await api.get('/messages/users');
      // Filter out current user (should already be filtered by backend)
      const filteredUsers = response.data.filter(u => u.email !== user.email);
      setAllUsers(filteredUsers);
    } catch (error) {
      console.error('Failed to fetch users:', error);
      // Fallback: try a different endpoint or show an error
      alert('Unable to load users for new conversations. Please try again later.');
    } finally {
      setLoadingUsers(false);
    }
  };

  const startNewConversation = (selectedUser) => {
    setSelectedChat(selectedUser);
    setShowNewConversation(false);
    // Clear any existing messages since this is a new conversation
    setMessages([]);
  };

  const fetchMessages = async (email) => {
    try {
      const response = await api.get(`/messages/conversation/${email}`);
      setMessages(response.data);
      // Mark messages as read
      await api.post(`/messages/mark-read/${email}`);
    } catch (error) {
      console.error('Failed to fetch messages:', error);
    }
  };

  const handleSendMessage = async () => {
    if (message.trim() && selectedChat) {
      setSending(true);
      try {
        await api.post('/messages', {
          receiverEmail: selectedChat.email,
          content: message.trim()
        });
        setMessage('');
        // Refresh messages
        fetchMessages(selectedChat.email);
        // Refresh conversations list to include the new conversation partner
        fetchConversations();
      } catch (error) {
        console.error('Failed to send message:', error);
        alert('Failed to send message. Please try again.');
      } finally {
        setSending(false);
      }
    }
  };

  const formatTime = (timestamp) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now - date;

    if (diff < 60000) return 'Just now';
    if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
    if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`;
    return `${Math.floor(diff / 86400000)}d ago`;
  };

  if (loading) {
    return <div style={{ padding: '20px', textAlign: 'center' }}>Loading conversations...</div>;
  }

  return (
    <div style={{ padding: '20px', maxWidth: '1200px', margin: '0 auto', display: 'flex', height: '80vh' }}>
      {/* Chat List */}
      <div style={{
        width: '30%',
        border: '1px solid #ddd',
        borderRadius: '8px',
        marginRight: '20px',
        overflowY: 'auto'
      }}>
        <div style={{
          padding: '15px',
          borderBottom: '1px solid #ddd',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center'
        }}>
          <h3 style={{ margin: 0 }}>Messages</h3>
          <button
            onClick={() => {
              setShowNewConversation(!showNewConversation);
              if (!showNewConversation && allUsers.length === 0) {
                fetchAllUsers();
              }
            }}
            style={{
              padding: '5px 10px',
              backgroundColor: '#007bff',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer',
              fontSize: '12px'
            }}
          >
            {showNewConversation ? 'Cancel' : 'New Chat'}
          </button>
        </div>

        {showNewConversation ? (
          <div style={{ padding: '15px' }}>
            <h4 style={{ margin: '0 0 10px 0' }}>Start New Conversation</h4>
            {loadingUsers ? (
              <div>Loading users...</div>
            ) : allUsers.length === 0 ? (
              <div>No users available</div>
            ) : (
              <div style={{ maxHeight: '300px', overflowY: 'auto' }}>
                {allUsers.map(user => (
                  <div
                    key={user.id}
                    onClick={() => startNewConversation(user)}
                    style={{
                      padding: '10px',
                      borderBottom: '1px solid #eee',
                      cursor: 'pointer',
                      backgroundColor: '#f9f9f9',
                      borderRadius: '4px',
                      marginBottom: '5px'
                    }}
                  >
                    <div style={{ fontWeight: 'bold' }}>{user.name}</div>
                    <div style={{ fontSize: '12px', color: '#666' }}>
                      {user.email} • {user.role}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        ) : (
          <>
            {conversations.length === 0 ? (
              <div style={{ padding: '15px', color: '#666' }}>
                No conversations yet. Click "New Chat" to start messaging!
              </div>
            ) : (
              conversations.map(partner => (
                <div
                  key={partner.id}
                  onClick={() => setSelectedChat(partner)}
                  style={{
                    padding: '15px',
                    borderBottom: '1px solid #eee',
                    cursor: 'pointer',
                    backgroundColor: selectedChat?.id === partner.id ? '#f0f8ff' : 'white'
                  }}
                >
                  <div style={{ fontWeight: 'bold' }}>{partner.name}</div>
                  <div style={{ fontSize: '14px', color: '#666', marginTop: '5px' }}>
                    {partner.email}
                  </div>
                </div>
              ))
            )}
          </>
        )}
      </div>

      {/* Chat Window */}
      <div style={{
        flex: 1,
        border: '1px solid #ddd',
        borderRadius: '8px',
        display: 'flex',
        flexDirection: 'column'
      }}>
        {selectedChat ? (
          <>
            <div style={{
              padding: '15px',
              borderBottom: '1px solid #ddd',
              backgroundColor: '#f8f9fa',
              borderRadius: '8px 8px 0 0'
            }}>
              <h4 style={{ margin: 0 }}>{selectedChat.name}</h4>
            </div>

            <div style={{ flex: 1, padding: '15px', overflowY: 'auto' }}>
              {messages.length === 0 ? (
                <div style={{ textAlign: 'center', color: '#666', marginTop: '50px' }}>
                  No messages yet. Start the conversation!
                </div>
              ) : (
                messages.map(msg => (
                  <div key={msg.id} style={{
                    marginBottom: '15px',
                    textAlign: msg.sender.email === user.email ? 'right' : 'left'
                  }}>
                    <div style={{
                      display: 'inline-block',
                      maxWidth: '70%',
                      padding: '10px',
                      borderRadius: '8px',
                      backgroundColor: msg.sender.email === user.email ? '#007bff' : '#f1f1f1',
                      color: msg.sender.email === user.email ? 'white' : 'black'
                    }}>
                      <div style={{ fontSize: '14px' }}>{msg.content}</div>
                      <div style={{ fontSize: '12px', opacity: 0.7, marginTop: '5px' }}>
                        {formatTime(msg.timestamp)}
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>

            <div style={{
              padding: '15px',
              borderTop: '1px solid #ddd',
              display: 'flex',
              gap: '10px'
            }}>
              <input
                type="text"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Type your message..."
                style={{
                  flex: 1,
                  padding: '10px',
                  border: '1px solid #ddd',
                  borderRadius: '4px'
                }}
                onKeyPress={(e) => e.key === 'Enter' && !sending && handleSendMessage()}
                disabled={sending}
              />
              <button
                onClick={handleSendMessage}
                disabled={sending || !message.trim()}
                style={{
                  padding: '10px 20px',
                  backgroundColor: sending ? '#ccc' : '#007bff',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: sending ? 'not-allowed' : 'pointer'
                }}
              >
                {sending ? 'Sending...' : 'Send'}
              </button>
            </div>
          </>
        ) : (
          <div style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            height: '100%',
            color: '#666'
          }}>
            Select a conversation to start messaging
          </div>
        )}
      </div>
    </div>
  );
}