import React, { useState } from 'react';
import { Menu, X, BarChart3, Users, Settings, LogOut, Home, FileText } from 'lucide-react';

const Sidebar = ({ userRole, onLogout }) => {
  const [isOpen, setIsOpen] = useState(true);

  const menuItems = {
    SUPERADMIN: [
      { icon: Home, label: 'Dashboard', path: '/superadmin-dashboard' },
      { icon: Users, label: 'Users', path: '/users' },
      { icon: FileText, label: 'Shelters', path: '/shelters' },
      { icon: BarChart3, label: 'Analytics', path: '/analytics' },
      { icon: Settings, label: 'Settings', path: '/settings' },
    ],
    ADMIN: [
      { icon: Home, label: 'Dashboard', path: '/admin-dashboard' },
      { icon: Users, label: 'Approvals', path: '/approvals' },
      { icon: FileText, label: 'Pet Listings', path: '/pets' },
      { icon: BarChart3, label: 'Reports', path: '/reports' },
    ],
    SHELTER: [
      { icon: Home, label: 'Dashboard', path: '/shelter-dashboard' },
      { icon: FileText, label: 'My Pets', path: '/my-pets' },
      { icon: Users, label: 'Applications', path: '/applications' },
      { icon: BarChart3, label: 'Analytics', path: '/my-analytics' },
    ],
    ADOPTER: [
      { icon: Home, label: 'Home', path: '/home' },
      { icon: FileText, label: 'My Applications', path: '/my-applications' },
      { icon: Users, label: 'Saved Pets', path: '/saved' },
    ]
  };

  const items = menuItems[userRole] || menuItems.ADOPTER;

  return (
    <div className={`fixed left-0 top-0 h-screen glass-effect transition-all duration-300 ${
      isOpen ? 'w-64' : 'w-20'
    } z-40 border-r border-white/20`}>

      {/* Header */}
      <div className="flex items-center justify-between p-6">
        {isOpen && <h2 className="text-white font-bold text-xl">🐾 Fur & Feathers</h2>}
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="text-white hover:bg-white/10 p-2 rounded-lg transition"
        >
          {isOpen ? <X size={20} /> : <Menu size={20} />}
        </button>
      </div>

      {/* Menu Items */}
      <nav className="mt-8 px-4 space-y-2">
        {items.map((item, idx) => (
          <a
            key={idx}
            href={item.path}
            className="flex items-center gap-4 px-4 py-3 rounded-lg text-white/80 hover:bg-white/10 hover:text-white transition group"
          >
            <item.icon size={20} className="flex-shrink-0" />
            {isOpen && <span className="truncate">{item.label}</span>}
          </a>
        ))}
      </nav>

      {/* Logout Button */}
      <button
        onClick={onLogout}
        className="absolute bottom-6 left-0 right-0 mx-4 flex items-center gap-4 px-4 py-3 rounded-lg bg-red-500/20 text-red-300 hover:bg-red-500/30 transition"
      >
        <LogOut size={20} className="flex-shrink-0" />
        {isOpen && <span>Logout</span>}
      </button>
    </div>
  );
};

export default Sidebar;