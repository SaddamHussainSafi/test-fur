import React from 'react';
import clsx from 'clsx';

const ChartCard = ({ title, subtitle, children, actions, className }) => {
  return (
    <div className={clsx('glass-card p-6', className)}>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold text-white">{title}</h3>
          {subtitle && <p className="text-white/60 text-sm mt-1">{subtitle}</p>}
        </div>
        {actions && <div className="flex gap-2">{actions}</div>}
      </div>
      <div className="w-full h-full">
        {children}
      </div>
    </div>
  );
};

export default ChartCard;