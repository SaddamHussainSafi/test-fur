package com.furandfeathers.util;

public enum Role {
    ADOPTER,
    SHELTER,
    ADMIN
}
