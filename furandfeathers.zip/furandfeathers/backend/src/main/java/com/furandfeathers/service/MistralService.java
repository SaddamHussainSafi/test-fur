package com.furandfeathers.service;

import com.furandfeathers.model.Conversation;
import com.furandfeathers.model.DeepseekDataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class MistralService {

    private static String currentContext = "welcome";
    private static String homeType = "";
    private static String activityLevel = "";
    private static String personality = "";

    @Value("${huggingface.api.url}")
    private String apiUrl;

    @Value("${huggingface.api.key}")
    private String apiKey;

    @Autowired
    private DeepseekDatasetService datasetService;

    public Map<String, Object> chat(String userMessage) {
        DeepseekDataset dataset = datasetService.getDataset();
        List<Conversation> conversations = dataset.getConversations();

        // Find matching conversation in current context
        for (Conversation conv : conversations) {
            if (conv.getContext().equals(currentContext) &&
                userMessage.toLowerCase().contains(conv.getUserInput().toLowerCase())) {
                // Set preferences based on context
                if ("living_situation".equals(currentContext)) {
                    if (userMessage.toLowerCase().contains("apartment") || userMessage.toLowerCase().contains("condo")) {
                        homeType = "apartment";
                    } else if (userMessage.toLowerCase().contains("house")) {
                        homeType = "house";
                    }
                } else if ("activity_level".equals(currentContext)) {
                    if (userMessage.toLowerCase().contains("active") || userMessage.toLowerCase().contains("daily")) {
                        activityLevel = "active";
                    } else if (userMessage.toLowerCase().contains("relaxed") || userMessage.toLowerCase().contains("quiet")) {
                        activityLevel = "relaxed";
                    }
                } else if ("affection_level".equals(currentContext)) {
                    if (userMessage.toLowerCase().contains("cuddly") || userMessage.toLowerCase().contains("affectionate")) {
                        personality = "cuddly";
                    } else if (userMessage.toLowerCase().contains("independent")) {
                        personality = "independent";
                    }
                }

                currentContext = conv.getNextContext();
                if ("recommendation".equals(currentContext)) {
                    // Get recommendations
                    Map<String, Object> result = new HashMap<>();
                    result.put("reply", conv.getExpectedResponse());
                    result.put("showRecommendations", true);
                    result.put("preferences", Map.of("homeType", homeType, "activityLevel", activityLevel, "personality", personality));
                    return result;
                }
                return Map.of("reply", conv.getExpectedResponse());
            }
        }

        // If no match, find general responses
        for (Conversation conv : conversations) {
            if (userMessage.toLowerCase().contains(conv.getUserInput().toLowerCase())) {
                currentContext = conv.getNextContext();
                return Map.of("reply", conv.getExpectedResponse());
            }
        }

        // Default response
        return Map.of("reply", "I'm here to help you find your perfect pet! Could you tell me about your living situation?");
    }
}